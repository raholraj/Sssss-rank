package com.powerfiles.channels

import android.content.Context
import android.os.Environment
import android.webkit.MimeTypeMap
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.security.MessageDigest

class FileChannel(private val context: Context, messenger: BinaryMessenger) {
    init {
        MethodChannel(messenger, "com.powerfiles/files").setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "listDir" -> {
                        val path = call.argument<String>("path") ?: Environment.getExternalStorageDirectory().absolutePath
                        val showHidden = call.argument<Boolean>("showHidden") ?: false
                        result.success(listDirectory(path, showHidden))
                    }
                    "readFile" -> {
                        val path = call.argument<String>("path")!!
                        result.success(File(path).readText())
                    }
                    "writeFile" -> {
                        val path = call.argument<String>("path")!!
                        val content = call.argument<String>("content")!!
                        File(path).writeText(content)
                        result.success(true)
                    }
                    "deleteFile" -> {
                        val path = call.argument<String>("path")!!
                        result.success(deleteRecursive(File(path)))
                    }
                    "copyFile" -> {
                        val src = call.argument<String>("src")!!
                        val dest = call.argument<String>("dest")!!
                        File(src).copyRecursively(File(dest), overwrite = true)
                        result.success(true)
                    }
                    "moveFile" -> {
                        val src = call.argument<String>("src")!!
                        val dest = call.argument<String>("dest")!!
                        val srcFile = File(src)
                        val destFile = File(dest)
                        if (srcFile.renameTo(destFile)) {
                            result.success(true)
                        } else {
                            srcFile.copyRecursively(destFile, overwrite = true)
                            srcFile.deleteRecursively()
                            result.success(true)
                        }
                    }
                    "createFolder" -> {
                        val path = call.argument<String>("path")!!
                        result.success(File(path).mkdirs())
                    }
                    "renameFile" -> {
                        val path = call.argument<String>("path")!!
                        val newName = call.argument<String>("newName")!!
                        val file = File(path)
                        val newFile = File(file.parent, newName)
                        result.success(file.renameTo(newFile))
                    }
                    "getFileInfo" -> {
                        val path = call.argument<String>("path")!!
                        result.success(getFileInfo(path))
                    }
                    "getFileHash" -> {
                        val path = call.argument<String>("path")!!
                        val algorithm = call.argument<String>("algorithm") ?: "MD5"
                        result.success(computeHash(path, algorithm))
                    }
                    "getFolderSize" -> {
                        val path = call.argument<String>("path")!!
                        result.success(getFolderSize(File(path)))
                    }
                    "searchFiles" -> {
                        val query = call.argument<String>("query")!!
                        val path = call.argument<String>("path") ?: Environment.getExternalStorageDirectory().absolutePath
                        val extension = call.argument<String>("extension")
                        result.success(searchFiles(query, path, extension))
                    }
                    "getStorageRoot" -> {
                        result.success(Environment.getExternalStorageDirectory().absolutePath)
                    }
                    "exists" -> {
                        val path = call.argument<String>("path")!!
                        result.success(File(path).exists())
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("FILE_ERROR", e.message, null)
            }
        }
    }

    private fun listDirectory(path: String, showHidden: Boolean): List<Map<String, Any?>> {
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory) return emptyList()

        val files = dir.listFiles() ?: return emptyList()
        return files
            .filter { showHidden || !it.name.startsWith(".") }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            .map { file ->
                mapOf(
                    "name" to file.name,
                    "path" to file.absolutePath,
                    "isDirectory" to file.isDirectory,
                    "size" to if (file.isFile) file.length() else 0L,
                    "lastModified" to file.lastModified(),
                    "mimeType" to getMimeType(file),
                    "isHidden" to file.isHidden,
                    "canRead" to file.canRead(),
                    "canWrite" to file.canWrite(),
                    "extension" to file.extension
                )
            }
    }

    private fun getMimeType(file: File): String? {
        if (file.isDirectory) return "inode/directory"
        val ext = file.extension.lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
    }

    private fun getFileInfo(path: String): Map<String, Any?> {
        val file = File(path)
        return mapOf(
            "name" to file.name,
            "path" to file.absolutePath,
            "size" to if (file.isFile) file.length() else getFolderSize(file),
            "lastModified" to file.lastModified(),
            "isDirectory" to file.isDirectory,
            "mimeType" to getMimeType(file),
            "canRead" to file.canRead(),
            "canWrite" to file.canWrite(),
            "extension" to file.extension,
            "parent" to file.parent,
            "isHidden" to file.isHidden
        )
    }

    private fun computeHash(path: String, algorithm: String): String {
        val digest = MessageDigest.getInstance(algorithm)
        File(path).inputStream().use { stream ->
            val buffer = ByteArray(8192)
            var bytes = stream.read(buffer)
            while (bytes != -1) {
                digest.update(buffer, 0, bytes)
                bytes = stream.read(buffer)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun getFolderSize(folder: File): Long {
        if (!folder.exists()) return 0L
        if (folder.isFile) return folder.length()
        var size = 0L
        folder.walkTopDown().forEach { file ->
            if (file.isFile) size += file.length()
        }
        return size
    }

    private fun deleteRecursive(file: File): Boolean {
        return if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    private fun searchFiles(query: String, rootPath: String, extension: String?): List<Map<String, Any?>> {
        val results = mutableListOf<Map<String, Any?>>()
        val root = File(rootPath)
        if (!root.exists()) return results

        root.walkTopDown()
            .filter { file ->
                val nameMatch = file.name.contains(query, ignoreCase = true)
                val extMatch = extension == null || file.extension.equals(extension, ignoreCase = true)
                nameMatch && extMatch
            }
            .take(200)
            .forEach { file ->
                results.add(mapOf(
                    "name" to file.name,
                    "path" to file.absolutePath,
                    "isDirectory" to file.isDirectory,
                    "size" to file.length(),
                    "lastModified" to file.lastModified()
                ))
            }
        return results
    }
}
