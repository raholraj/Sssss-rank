package com.powerfiles.channels

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.documentfile.provider.DocumentFile
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

class SAFChannel(private val activity: Activity, messenger: BinaryMessenger) {
    private var pendingResult: MethodChannel.Result? = null
    private val PREFS = "powerfiles_saf"

    init {
        MethodChannel(messenger, "com.powerfiles/saf").setMethodCallHandler { call, result ->
            when (call.method) {
                "requestAndroidDataAccess" -> requestAndroidDataAccess(result)
                "hasAndroidDataAccess" -> result.success(hasAndroidDataAccess())
                "listSAFDirectory" -> {
                    val uriString = call.argument<String>("uri")!!
                    result.success(listSAFDirectory(uriString))
                }
                "readSAFFile" -> {
                    val uriString = call.argument<String>("uri")!!
                    result.success(readSAFFile(uriString))
                }
                "writeSAFFile" -> {
                    val uriString = call.argument<String>("uri")!!
                    val content = call.argument<String>("content")!!
                    result.success(writeSAFFile(uriString, content))
                }
                "deleteSAFFile" -> {
                    val uriString = call.argument<String>("uri")!!
                    result.success(deleteSAFFile(uriString))
                }
                "getPersistedPermissions" -> result.success(getPersistedPermissions())
                else -> result.notImplemented()
            }
        }
    }

    fun requestAndroidDataAccess(result: MethodChannel.Result) {
        pendingResult = result
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                putExtra("android.provider.extra.INITIAL_URI",
                    Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid%2Fdata"))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
            }
            activity.startActivityForResult(intent, 1002)
        } else {
            result.success("not_needed")
        }
    }

    fun handleActivityResult(resultCode: Int, data: Intent?) {
        val result = pendingResult ?: return
        pendingResult = null

        if (resultCode == Activity.RESULT_OK && data?.data != null) {
            val uri = data.data!!
            activity.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            // Save the URI for later use
            val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            prefs.edit().putString("android_data_uri", uri.toString()).apply()
            result.success("granted")
        } else {
            result.success("denied")
        }
    }

    private fun hasAndroidDataAccess(): Boolean {
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val uriString = prefs.getString("android_data_uri", null) ?: return false
        val uri = Uri.parse(uriString)
        val perms = activity.contentResolver.persistedUriPermissions
        return perms.any { it.uri == uri && it.isReadPermission }
    }

    private fun listSAFDirectory(uriString: String): List<Map<String, Any?>> {
        val uri = Uri.parse(uriString)
        val docFile = DocumentFile.fromTreeUri(activity, uri) ?: return emptyList()
        return docFile.listFiles().map { file ->
            mapOf(
                "name" to file.name,
                "uri" to file.uri.toString(),
                "isDirectory" to file.isDirectory,
                "size" to file.length(),
                "lastModified" to file.lastModified(),
                "type" to file.type,
                "canRead" to file.canRead(),
                "canWrite" to file.canWrite()
            )
        }
    }

    private fun readSAFFile(uriString: String): String {
        val uri = Uri.parse(uriString)
        return activity.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
    }

    private fun writeSAFFile(uriString: String, content: String): Boolean {
        val uri = Uri.parse(uriString)
        return try {
            activity.contentResolver.openOutputStream(uri)?.use { stream ->
                stream.write(content.toByteArray())
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun deleteSAFFile(uriString: String): Boolean {
        val uri = Uri.parse(uriString)
        val docFile = DocumentFile.fromSingleUri(activity, uri) ?: return false
        return docFile.delete()
    }

    private fun getPersistedPermissions(): List<String> {
        return activity.contentResolver.persistedUriPermissions.map { it.uri.toString() }
    }
}
