package com.powerfiles.channels

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File

class PackageChannel(private val context: Context, messenger: BinaryMessenger) {
    init {
        MethodChannel(messenger, "com.powerfiles/packages").setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "getInstalledApps" -> result.success(getInstalledApps())
                    "installApk" -> {
                        val path = call.argument<String>("path")!!
                        installApk(path)
                        result.success(true)
                    }
                    "getApkInfo" -> {
                        val path = call.argument<String>("path")!!
                        result.success(getApkInfo(path))
                    }
                    "openFile" -> {
                        val path = call.argument<String>("path")!!
                        val mimeType = call.argument<String>("mimeType") ?: "*/*"
                        openFile(path, mimeType)
                        result.success(true)
                    }
                    "shareFile" -> {
                        val path = call.argument<String>("path")!!
                        shareFile(path)
                        result.success(true)
                    }
                    "uninstallApp" -> {
                        val packageName = call.argument<String>("packageName")!!
                        uninstallApp(packageName)
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("PACKAGE_ERROR", e.message, null)
            }
        }
    }

    private fun getInstalledApps(): List<Map<String, Any?>> {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        return apps.map { app ->
            try {
                val packageInfo = pm.getPackageInfo(app.packageName, 0)
                mapOf(
                    "packageName" to app.packageName,
                    "appName" to pm.getApplicationLabel(app).toString(),
                    "versionName" to packageInfo.versionName,
                    "versionCode" to if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                        packageInfo.longVersionCode.toInt() else packageInfo.versionCode,
                    "sourceDir" to app.sourceDir,
                    "dataDir" to app.dataDir,
                    "isSystemApp" to ((app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0),
                    "installDate" to packageInfo.firstInstallTime,
                    "updateDate" to packageInfo.lastUpdateTime,
                    "minSdkVersion" to if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) app.minSdkVersion else 0
                )
            } catch (e: Exception) {
                null
            }
        }.filterNotNull()
    }

    private fun installApk(path: String) {
        val file = File(path)
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } else {
            Uri.fromFile(file)
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(intent)
    }

    private fun getApkInfo(path: String): Map<String, Any?> {
        val pm = context.packageManager
        val packageInfo = pm.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES) ?: return emptyMap()
        packageInfo.applicationInfo?.sourceDir = path
        packageInfo.applicationInfo?.publicSourceDir = path

        return mapOf(
            "packageName" to packageInfo.packageName,
            "appName" to (packageInfo.applicationInfo?.let { pm.getApplicationLabel(it).toString() } ?: "Unknown"),
            "versionName" to packageInfo.versionName,
            "versionCode" to packageInfo.versionCode,
            "minSdkVersion" to if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                packageInfo.applicationInfo?.minSdkVersion ?: 0 else 0,
            "targetSdkVersion" to (packageInfo.applicationInfo?.targetSdkVersion ?: 0),
            "fileSize" to File(path).length()
        )
    }

    private fun openFile(path: String, mimeType: String) {
        val file = File(path)
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } else {
            Uri.fromFile(file)
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(intent, "Open with").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }

    private fun shareFile(path: String) {
        val file = File(path)
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } else {
            Uri.fromFile(file)
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "Share").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }

    private fun uninstallApp(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:$packageName")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
