package com.powerfiles.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.powerfiles.MainActivity
import java.io.File
import java.util.concurrent.TimeUnit

class ScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    companion object {
        const val CHANNEL_ID = "powerfiles_scans"
        const val WORK_TAG = "powerfiles_scan"

        fun scheduleDaily(context: Context) {
            val request = PeriodicWorkRequestBuilder<ScanWorker>(24, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder()
                    .setRequiresBatteryNotLow(true)
                    .build())
                .addTag(WORK_TAG)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_TAG, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        fun runOnce(context: Context) {
            val request = OneTimeWorkRequestBuilder<ScanWorker>()
                .addTag(WORK_TAG)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }

    override suspend fun doWork(): Result {
        createNotificationChannel()
        showProgressNotification("PowerFiles scanning storage...")

        return try {
            val root = android.os.Environment.getExternalStorageDirectory()
            val stats = scanStorage(root)
            showCompleteNotification(stats)
            Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }

    private data class ScanStats(
        val junkCount: Int,
        val junkSize: Long,
        val dupCount: Int,
        val dupWasted: Long,
        val freeSpace: Long
    )

    private fun scanStorage(root: File): ScanStats {
        var junkCount = 0
        var junkSize = 0L
        val sizeMap = mutableMapOf<Long, MutableList<String>>()
        var dupCount = 0
        var dupWasted = 0L

        val junkExts = setOf("tmp", "temp", "bak", "old", "cache", "log")
        val junkNames = setOf("Thumbs.db", ".DS_Store", "desktop.ini")

        root.walkTopDown()
            .filter { it.exists() }
            .forEach { file ->
                // Junk detection
                val isJunk = when {
                    file.isFile && file.length() == 0L -> true
                    file.isFile && file.extension.lowercase() in junkExts -> true
                    file.isFile && file.name in junkNames -> true
                    else -> false
                }
                if (isJunk) { junkCount++; junkSize += file.length() }

                // Duplicate candidates
                if (file.isFile && file.length() > 1024) {
                    sizeMap.getOrPut(file.length()) { mutableListOf() }.add(file.absolutePath)
                }
            }

        // Count size-based duplicate groups
        sizeMap.filter { it.value.size > 1 }.forEach { (size, paths) ->
            dupCount += paths.size - 1
            dupWasted += size * (paths.size - 1)
        }

        val stat = android.os.StatFs(root.absolutePath)
        val freeSpace = stat.availableBytes

        return ScanStats(junkCount, junkSize, dupCount, dupWasted, freeSpace)
    }

    private fun showProgressNotification(message: String) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(applicationContext, MainActivity::class.java)
        val pi = PendingIntent.getActivity(applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val n = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("PowerFiles")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setProgress(0, 0, true)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        nm.notify(1001, n)
    }

    private fun showCompleteNotification(stats: ScanStats) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(1001)

        if (stats.junkCount == 0 && stats.dupCount == 0) return

        val freeGb = stats.freeSpace / (1024f * 1024f * 1024f)
        val lines = mutableListOf<String>()
        if (stats.junkCount > 0) lines.add("🗑️ ${stats.junkCount} junk files (${formatSize(stats.junkSize)})")
        if (stats.dupCount > 0) lines.add("📄 ${stats.dupCount} duplicate files (${formatSize(stats.dupWasted)} wasted)")
        lines.add("💾 ${String.format("%.1f", freeGb)} GB free")

        val intent = Intent(applicationContext, MainActivity::class.java)
        val pi = PendingIntent.getActivity(applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val n = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("Storage scan complete")
            .setContentText(lines.first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(lines.joinToString("\n")))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(1002, n)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Storage Scans", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Background storage scan notifications" }
            val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun formatSize(bytes: Long): String {
        return when {
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            bytes < 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
            else -> String.format("%.1f GB", bytes / (1024f * 1024f * 1024f))
        }
    }
}

class ScanService
