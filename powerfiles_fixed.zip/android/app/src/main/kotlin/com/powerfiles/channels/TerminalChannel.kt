package com.powerfiles.channels

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.*
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class TerminalChannel(private val context: Context, messenger: BinaryMessenger) {
    private val sessions = mutableMapOf<String, TerminalSession>()
    private val bgExecutor = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())

    init {
        MethodChannel(messenger, "com.powerfiles/terminal").setMethodCallHandler { call, result ->
            when (call.method) {
                "createSession" -> {
                    val id = call.argument<String>("id") ?: "default"
                    val workDir = call.argument<String>("workDir") ?: context.filesDir.absolutePath
                    createSession(id, workDir)
                    result.success(id)
                }
                "sendInput" -> {
                    val id = call.argument<String>("id") ?: "default"
                    val input = call.argument<String>("input") ?: ""
                    sessions[id]?.write(input)
                    result.success(null)
                }
                "killSession" -> {
                    val id = call.argument<String>("id") ?: "default"
                    sessions[id]?.destroy()
                    sessions.remove(id)
                    result.success(null)
                }
                "runCommand" -> {
                    val command = call.argument<String>("command")!!
                    val workDir = call.argument<String>("workDir")
                    // Run off the platform thread so long/blocking commands can't freeze the UI (ANR).
                    bgExecutor.execute {
                        val output = runCommand(command, workDir)
                        mainHandler.post { result.success(output) }
                    }
                }
                "resize" -> {
                    val id = call.argument<String>("id") ?: "default"
                    val rows = call.argument<Int>("rows") ?: 24
                    val cols = call.argument<Int>("cols") ?: 80
                    sessions[id]?.resize(rows, cols)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        EventChannel(messenger, "com.powerfiles/terminal_output").setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    // Handled per session
                }
                override fun onCancel(arguments: Any?) {}
            }
        )
    }

    private fun createSession(id: String, workDir: String) {
        sessions[id]?.destroy()
        sessions[id] = TerminalSession(context, workDir)
    }

    private fun runCommand(command: String, workDir: String?): Map<String, Any> {
        return try {
            val pb = ProcessBuilder("/system/bin/sh", "-c", command)
            if (workDir != null) pb.directory(File(workDir))
            pb.redirectErrorStream(true)
            val process = pb.start()
            val output = process.inputStream.bufferedReader().readText()
            val finished = process.waitFor(30, TimeUnit.SECONDS)
            if (!finished) {
                process.destroy()
                return mapOf("output" to "$output\n[Command timed out after 30s, killed]",
                    "exitCode" to -1, "success" to false)
            }
            val exitCode = process.exitValue()
            mapOf("output" to output, "exitCode" to exitCode, "success" to (exitCode == 0))
        } catch (e: Exception) {
            mapOf("output" to (e.message ?: "Error"), "exitCode" to -1, "success" to false)
        }
    }

    inner class TerminalSession(private val context: Context, workDir: String) {
        private var process: Process? = null
        private var writer: OutputStreamWriter? = null

        init {
            val env = mutableListOf(
                "HOME=${context.filesDir.absolutePath}",
                "TERM=xterm-256color",
                "PATH=/system/bin:/system/xbin:/data/data/com.termux/files/usr/bin",
                "ANDROID_DATA=${android.os.Environment.getDataDirectory()}",
                "EXTERNAL_STORAGE=${android.os.Environment.getExternalStorageDirectory()}"
            )

            val shell = findShell()
            val pb = ProcessBuilder(shell)
                .apply {
                    directory(File(workDir))
                    environment().apply {
                        put("HOME", context.filesDir.absolutePath)
                        put("TERM", "xterm-256color")
                        put("PATH", "/system/bin:/system/xbin" +
                            ":/data/data/com.termux/files/usr/bin" +
                            ":/data/data/com.termux/files/usr/local/bin")
                    }
                    redirectErrorStream(true)
                }
            process = pb.start()
            writer = OutputStreamWriter(process!!.outputStream)
        }

        private fun findShell(): String {
            val shells = listOf(
                "/data/data/com.termux/files/usr/bin/bash",
                "/system/bin/sh",
                "/bin/sh"
            )
            return shells.firstOrNull { File(it).exists() } ?: "/system/bin/sh"
        }

        fun write(input: String) {
            try {
                writer?.write(input)
                writer?.flush()
            } catch (e: Exception) {
                // Session closed
            }
        }

        fun resize(rows: Int, cols: Int) {
            // Resize terminal - requires native call on rooted devices
            // For non-root, we just track the size
        }

        fun destroy() {
            try {
                writer?.close()
                process?.destroy()
            } catch (e: Exception) { }
        }

        fun isAlive() = process?.isAlive == true
    }
}
