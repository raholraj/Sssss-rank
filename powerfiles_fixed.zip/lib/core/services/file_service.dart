import 'package:flutter/services.dart';
import '../models/file_item.dart';

class FileService {
  static const _channel = MethodChannel('com.powerfiles/files');
  static const _permChannel = MethodChannel('com.powerfiles/permissions');
  static const _storageChannel = MethodChannel('com.powerfiles/storage');
  static const _packageChannel = MethodChannel('com.powerfiles/packages');
  static const _safChannel = MethodChannel('com.powerfiles/saf');

  // ── Permissions ──
  Future<bool> checkManageStorage() async =>
      await _permChannel.invokeMethod('checkManageStorage') as bool;

  Future<String> requestManageStorage() async =>
      await _permChannel.invokeMethod('requestManageStorage') as String;

  Future<void> openAppSettings() async =>
      _permChannel.invokeMethod('openAppSettings');

  // ── SAF: Android/data & Android/obb access (scoped storage workaround) ──
  // Returns "granted" / "denied" / "not_needed" (matches native SAFChannel.requestAndroidDataAccess result)
  Future<String> requestAndroidDataAccess() async =>
      await _permChannel.invokeMethod('requestSAFAndroidData') as String? ?? 'denied';

  Future<bool> hasAndroidDataAccess() async =>
      await _safChannel.invokeMethod('hasAndroidDataAccess') as bool? ?? false;

  Future<List<Map>> listSAFDirectory(String uri) async {
    final raw = await _safChannel.invokeMethod('listSAFDirectory', {'uri': uri});
    return (raw as List).map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<String> readSAFFile(String uri) async =>
      await _safChannel.invokeMethod('readSAFFile', {'uri': uri}) as String;

  Future<bool> writeSAFFile(String uri, String content) async =>
      await _safChannel.invokeMethod('writeSAFFile', {'uri': uri, 'content': content}) as bool;

  Future<bool> deleteSAFFile(String uri) async =>
      await _safChannel.invokeMethod('deleteSAFFile', {'uri': uri}) as bool;

  Future<List<String>> getPersistedSAFPermissions() async {
    final raw = await _safChannel.invokeMethod('getPersistedPermissions');
    return (raw as List).map((e) => e.toString()).toList();
  }

  // ── File Operations ──
  Future<List<FileItem>> listDirectory(String path, {bool showHidden = false}) async {
    final raw = await _channel.invokeMethod('listDir', {'path': path, 'showHidden': showHidden});
    final list = raw as List;
    return list.map((e) => FileItem.fromMap(e as Map)).toList();
  }

  Future<String> readFile(String path) async =>
      await _channel.invokeMethod('readFile', {'path': path}) as String;

  Future<bool> writeFile(String path, String content) async =>
      await _channel.invokeMethod('writeFile', {'path': path, 'content': content}) as bool;

  Future<bool> deleteFile(String path) async =>
      await _channel.invokeMethod('deleteFile', {'path': path}) as bool;

  Future<bool> copyFile(String src, String dest) async =>
      await _channel.invokeMethod('copyFile', {'src': src, 'dest': dest}) as bool;

  Future<bool> moveFile(String src, String dest) async =>
      await _channel.invokeMethod('moveFile', {'src': src, 'dest': dest}) as bool;

  Future<bool> createFolder(String path) async =>
      await _channel.invokeMethod('createFolder', {'path': path}) as bool;

  Future<bool> renameFile(String path, String newName) async =>
      await _channel.invokeMethod('renameFile', {'path': path, 'newName': newName}) as bool;

  Future<Map<dynamic, dynamic>> getFileInfo(String path) async =>
      await _channel.invokeMethod('getFileInfo', {'path': path}) as Map;

  Future<String> getFileHash(String path, {String algorithm = 'MD5'}) async =>
      await _channel.invokeMethod('getFileHash', {'path': path, 'algorithm': algorithm}) as String;

  Future<int> getFolderSize(String path) async =>
      await _channel.invokeMethod('getFolderSize', {'path': path}) as int;

  Future<List<FileItem>> searchFiles(String query, String path, {String? extension}) async {
    final raw = await _channel.invokeMethod('searchFiles', {
      'query': query, 'path': path, 'extension': extension,
    });
    final list = raw as List;
    return list.map((e) => FileItem.fromMap(e as Map)).toList();
  }

  Future<String> getStorageRoot() async =>
      await _channel.invokeMethod('getStorageRoot') as String;

  Future<bool> exists(String path) async =>
      await _channel.invokeMethod('exists', {'path': path}) as bool;

  // ── Storage Stats ──
  Future<Map<dynamic, dynamic>> getStorageStats() async =>
      await _storageChannel.invokeMethod('getStorageStats') as Map;

  Future<Map<dynamic, dynamic>> getCategoryBreakdown() async =>
      await _storageChannel.invokeMethod('getCategoryBreakdown') as Map;

  Future<List<Map>> getAppStorageList() async {
    final raw = await _storageChannel.invokeMethod('getAppStorageList');
    return (raw as List).map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map>> getMediaByFolder(String type) async {
    final raw = await _storageChannel.invokeMethod('getMediaByFolder', {'type': type});
    return (raw as List).map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map>> getDuplicateCandidates(String path) async {
    final raw = await _storageChannel.invokeMethod('getDuplicateCandidates', {'path': path});
    return (raw as List).map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map>> getJunkFiles(String path) async {
    final raw = await _storageChannel.invokeMethod('getJunkFiles', {'path': path});
    return (raw as List).map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map>> getLargeFiles(String path, {int minSizeMB = 10}) async {
    final raw = await _storageChannel.invokeMethod('getLargeFiles', {
      'path': path, 'minSize': minSizeMB * 1024 * 1024,
    });
    return (raw as List).map((e) => Map<dynamic, dynamic>.from(e as Map)).toList();
  }

  Future<String?> getSDCardPath() async =>
      await _storageChannel.invokeMethod('getSDCardPath') as String?;

  // ── Package Operations ──
  Future<void> installApk(String path) async =>
      _packageChannel.invokeMethod('installApk', {'path': path});

  Future<Map> getApkInfo(String path) async =>
      await _packageChannel.invokeMethod('getApkInfo', {'path': path}) as Map;

  Future<void> openFile(String path, {String mimeType = '*/*'}) async =>
      _packageChannel.invokeMethod('openFile', {'path': path, 'mimeType': mimeType});

  Future<void> shareFile(String path) async =>
      _packageChannel.invokeMethod('shareFile', {'path': path});
}

// Singleton accessor
final fileService = FileService();
