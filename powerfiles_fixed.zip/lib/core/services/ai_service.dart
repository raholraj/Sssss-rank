import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ═══════════════════════════════════════
//  Provider types
// ═══════════════════════════════════════
enum AIProviderType {
  openai, anthropic, google, deepseek, groq, openrouter,
  mistral, cohere, perplexity, cerebras, together, xai,
  qwen, kimi, huggingface, cloudflare, ollama, lmstudio,
  nvidia, sambanova, githubmodels, novita, glm,
  openaiCompatible, local
}

// ═══════════════════════════════════════
//  AIProvider model
// ═══════════════════════════════════════
class AIProvider {
  final String id;
  final String name;
  final String baseUrl;
  final String apiKey;
  final String selectedModel;
  final List<String> models;
  final AIProviderType type;
  final bool isEnabled;

  const AIProvider({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.apiKey,
    required this.selectedModel,
    this.models = const [],
    required this.type,
    this.isEnabled = true,
  });

  AIProvider copyWith({
    String? apiKey, String? selectedModel, List<String>? models, bool? isEnabled,
  }) => AIProvider(
    id: id, name: name, baseUrl: baseUrl,
    apiKey: apiKey ?? this.apiKey,
    selectedModel: selectedModel ?? this.selectedModel,
    models: models ?? this.models,
    type: type, isEnabled: isEnabled ?? this.isEnabled,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'baseUrl': baseUrl,
    'apiKey': apiKey, 'selectedModel': selectedModel,
    'models': models, 'type': type.name, 'isEnabled': isEnabled,
  };

  factory AIProvider.fromJson(Map<String, dynamic> j) => AIProvider(
    id: j['id'], name: j['name'], baseUrl: j['baseUrl'],
    apiKey: j['apiKey'] ?? '', selectedModel: j['selectedModel'] ?? '',
    models: List<String>.from(j['models'] ?? []),
    type: AIProviderType.values.firstWhere((t) => t.name == j['type'],
        orElse: () => AIProviderType.openaiCompatible),
    isEnabled: j['isEnabled'] ?? true,
  );
}

// ═══════════════════════════════════════
//  Default fallback providers (pre-keyed)
//  Order: Gemini → Groq → OpenRouter
// ═══════════════════════════════════════
class _FallbackProviders {
  // Primary: Google Gemini
  static const gemini = AIProvider(
    id: 'google',
    name: 'Google Gemini (Auto)',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    apiKey: 'GuCqonqEHzzibAkGnyFUhG8J7Q3PYtOL',
    selectedModel: 'gemini-2.0-flash',
    type: AIProviderType.google,
    models: ['gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash'],
  );

  // Secondary: Groq
  static const groq = AIProvider(
    id: 'groq',
    name: 'Groq (Auto Fallback)',
    baseUrl: 'https://api.groq.com/openai/v1',
    apiKey: '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',
    selectedModel: 'llama-3.3-70b-versatile',
    type: AIProviderType.groq,
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'],
  );

  // Tertiary: OpenRouter
  static const openrouter = AIProvider(
    id: 'openrouter',
    name: 'OpenRouter (Auto Fallback)',
    baseUrl: 'https://openrouter.ai/api/v1',
    apiKey: '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',
    selectedModel: 'meta-llama/llama-3.3-70b-instruct:free',
    type: AIProviderType.openrouter,
    models: [
      'meta-llama/llama-3.3-70b-instruct:free',
      'google/gemini-2.0-flash-exp:free',
      'deepseek/deepseek-r1:free',
      'openai/gpt-4o',
    ],
  );

  static const List<AIProvider> ordered = [gemini, groq, openrouter];
}

// ═══════════════════════════════════════
//  All presets (for provider list UI)
// ═══════════════════════════════════════
class ProviderPresets {
  static const all = [
    _FallbackProviders.gemini,
    _FallbackProviders.groq,
    _FallbackProviders.openrouter,
    AIProvider(id: 'openai', name: 'OpenAI', type: AIProviderType.openai,
      baseUrl: 'https://api.openai.com/v1', apiKey: '',
      selectedModel: 'gpt-4o',
      models: ['gpt-4o','gpt-4o-mini','gpt-4-turbo','gpt-3.5-turbo','o1-mini']),
    AIProvider(id: 'anthropic', name: 'Anthropic Claude', type: AIProviderType.anthropic,
      baseUrl: 'https://api.anthropic.com', apiKey: '',
      selectedModel: 'claude-3-5-sonnet-20241022',
      models: ['claude-3-5-sonnet-20241022','claude-3-5-haiku-20241022','claude-3-opus-20240229']),
    AIProvider(id: 'deepseek', name: 'DeepSeek', type: AIProviderType.deepseek,
      baseUrl: 'https://api.deepseek.com/v1', apiKey: '',
      selectedModel: 'deepseek-chat',
      models: ['deepseek-chat','deepseek-reasoner','deepseek-coder']),
    AIProvider(id: 'mistral', name: 'Mistral AI', type: AIProviderType.mistral,
      baseUrl: 'https://api.mistral.ai/v1', apiKey: '',
      selectedModel: 'mistral-large-latest',
      models: ['mistral-large-latest','mistral-small-latest','codestral-latest']),
    AIProvider(id: 'xai', name: 'xAI Grok', type: AIProviderType.xai,
      baseUrl: 'https://api.x.ai/v1', apiKey: '',
      selectedModel: 'grok-2',
      models: ['grok-2','grok-2-mini','grok-3']),
    AIProvider(id: 'cerebras', name: 'Cerebras (Fastest)', type: AIProviderType.cerebras,
      baseUrl: 'https://api.cerebras.ai/v1', apiKey: '',
      selectedModel: 'llama3.1-70b',
      models: ['llama3.1-70b','llama3.1-8b']),
    AIProvider(id: 'perplexity', name: 'Perplexity (Web Search)', type: AIProviderType.perplexity,
      baseUrl: 'https://api.perplexity.ai', apiKey: '',
      selectedModel: 'sonar-pro',
      models: ['sonar-pro','sonar','sonar-reasoning']),
    AIProvider(id: 'ollama', name: 'Ollama (Local)', type: AIProviderType.ollama,
      baseUrl: 'http://localhost:11434', apiKey: '',
      selectedModel: 'llama3',
      models: ['llama3','mistral','phi3','gemma2']),
    AIProvider(id: 'sambanova', name: 'SambaNova (Free)', type: AIProviderType.sambanova,
      baseUrl: 'https://api.sambanova.ai/v1', apiKey: '',
      selectedModel: 'Meta-Llama-3.3-70B-Instruct',
      models: ['Meta-Llama-3.3-70B-Instruct','DeepSeek-R1','DeepSeek-V3']),
  ];
}

// ═══════════════════════════════════════
//  Chat message
// ═══════════════════════════════════════
class ChatMessage {
  final String role; // user / assistant / system
  final String content;
  final DateTime timestamp;
  final bool isStreaming;

  const ChatMessage({
    required this.role,
    required this.content,
    required this.timestamp,
    this.isStreaming = false,
  });

  ChatMessage copyWith({String? content, bool? isStreaming}) => ChatMessage(
    role: role, timestamp: timestamp,
    content: content ?? this.content,
    isStreaming: isStreaming ?? this.isStreaming,
  );

  Map<String, String> toApiMap() => {'role': role, 'content': content};
}

// ═══════════════════════════════════════
//  AI Service
// ═══════════════════════════════════════
class AIService {
  static const _prefsKey = 'ai_providers_v2';
  static const _activeKey = 'active_provider_v2';
  static const _systemPromptKey = 'system_prompt';

  List<AIProvider> _providers = [];
  String? _activeProviderId;
  String? _lastUsedFallbackId;   // track which fallback was last successful

  List<AIProvider> get providers => List.unmodifiable(_providers);

  AIProvider? get activeProvider => _providers.cast<AIProvider?>()
      .firstWhere((p) => p?.id == _activeProviderId, orElse: () => null);

  // Which fallback was last successful (for UI badge)
  String? get lastUsedFallbackId => _lastUsedFallbackId;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_prefsKey) ?? [];
    if (raw.isEmpty) {
      // First launch: use preset list (includes pre-keyed fallback providers)
      _providers = List.from(ProviderPresets.all);
      _activeProviderId = 'google'; // start with Gemini
    } else {
      _providers = raw.map((s) => AIProvider.fromJson(jsonDecode(s))).toList();
      _activeProviderId = prefs.getString(_activeKey);
    }
    // Make sure the 3 fallback providers always exist with their keys
    _ensureFallbackProviders();
  }

  /// Ensure the 3 auto-fallback providers are always present with correct keys
  void _ensureFallbackProviders() {
    for (final fp in _FallbackProviders.ordered) {
      final idx = _providers.indexWhere((p) => p.id == fp.id);
      if (idx < 0) {
        _providers.insert(0, fp);
      } else if (_providers[idx].apiKey.isEmpty) {
        // Restore key if it was cleared
        _providers[idx] = _providers[idx].copyWith(apiKey: fp.apiKey);
      }
    }
  }

  Future<void> saveProvider(AIProvider provider) async {
    final idx = _providers.indexWhere((p) => p.id == provider.id);
    if (idx >= 0) _providers[idx] = provider;
    else _providers.add(provider);
    await _persist();
  }

  Future<void> removeProvider(String id) async {
    _providers.removeWhere((p) => p.id == id);
    if (_activeProviderId == id) _activeProviderId = _providers.firstOrNull?.id;
    await _persist();
  }

  Future<void> setActiveProvider(String id) async {
    _activeProviderId = id;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_activeKey, id);
  }

  Future<String> getSystemPrompt() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_systemPromptKey) ?? _defaultSystemPrompt;
  }

  Future<void> setSystemPrompt(String prompt) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_systemPromptKey, prompt);
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_prefsKey,
        _providers.map((p) => jsonEncode(p.toJson())).toList());
  }

  // ═══════════════════════════════════
  //  🔄 FALLBACK STREAM CHAT
  //  Tries Gemini → Groq → OpenRouter
  //  automatically if one fails
  // ═══════════════════════════════════
  Stream<String> streamChatWithFallback(
    List<ChatMessage> messages, {
    String? systemPrompt,
    void Function(String providerId, String providerName)? onProviderSwitch,
  }) async* {
    final sys = systemPrompt ?? _defaultSystemPrompt;

    // Build fallback chain: active provider first, then the 3 default fallbacks
    final chain = <AIProvider>[];
    final active = activeProvider;
    if (active != null) chain.add(active);
    for (final fp in _FallbackProviders.ordered) {
      if (!chain.any((p) => p.id == fp.id)) {
        // Get from _providers (may have user-updated key)
        final inList = _providers.firstWhere((p) => p.id == fp.id,
            orElse: () => fp);
        chain.add(inList);
      }
    }

    String lastError = '';
    for (final provider in chain) {
      try {
        onProviderSwitch?.call(provider.id, provider.name);
        bool gotAny = false;
        await for (final token in streamChat(provider, messages, systemPrompt: sys)) {
          gotAny = true;
          yield token;
        }
        if (gotAny) {
          _lastUsedFallbackId = provider.id;
          return; // success — stop trying
        }
      } catch (e) {
        lastError = e.toString();
        // This provider failed → try next
        continue;
      }
    }
    // All failed
    yield '\n\n⚠️ All AI providers failed. Last error: $lastError\nPlease check your internet connection or add a new API key in Settings → AI Providers.';
  }

  // ═══════════════════════════════════
  //  Single provider stream (used by fallback chain & direct calls)
  // ═══════════════════════════════════
  Stream<String> streamChat(
    AIProvider provider,
    List<ChatMessage> messages, {
    String? systemPrompt,
  }) async* {
    if (provider.apiKey.isEmpty) {
      throw Exception('No API key for ${provider.name}');
    }
    final sys = systemPrompt ?? _defaultSystemPrompt;
    switch (provider.type) {
      case AIProviderType.anthropic:
        yield* _streamAnthropic(provider, messages, sys);
      case AIProviderType.google:
        yield* _streamGoogle(provider, messages, sys);
      default:
        yield* _streamOpenAICompatible(provider, messages, sys);
    }
  }

  // ── OpenAI-compatible streaming ──
  Stream<String> _streamOpenAICompatible(
      AIProvider provider, List<ChatMessage> messages, String sys) async* {
    final msgList = [
      {'role': 'system', 'content': sys},
      ...messages.map((m) => m.toApiMap()),
    ];

    final req = http.Request('POST', Uri.parse('${provider.baseUrl}/chat/completions'));
    req.headers['Content-Type'] = 'application/json';
    req.headers['Authorization'] = 'Bearer ${provider.apiKey}';
    if (provider.type == AIProviderType.openrouter) {
      req.headers['HTTP-Referer'] = 'https://powerfiles.app';
      req.headers['X-Title'] = 'PowerFiles';
    }
    req.body = jsonEncode({
      'model': provider.selectedModel,
      'messages': msgList,
      'stream': true,
      'max_tokens': 4096,
      'temperature': 0.7,
    });

    final client = http.Client();
    try {
      final response = await client.send(req).timeout(const Duration(seconds: 30));
      if (response.statusCode != 200) {
        final body = await response.stream.bytesToString();
        throw Exception('${provider.name} error ${response.statusCode}: $body');
      }

      final stream = response.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter());
      await for (final line in stream) {
        if (!line.startsWith('data: ')) continue;
        final data = line.substring(6).trim();
        if (data == '[DONE]') break;
        try {
          final json = jsonDecode(data);
          final delta = json['choices']?[0]?['delta']?['content'];
          if (delta != null && delta is String && delta.isNotEmpty) yield delta;
        } catch (_) {}
      }
    } finally {
      client.close();
    }
  }

  // ── Anthropic streaming ──
  Stream<String> _streamAnthropic(
      AIProvider provider, List<ChatMessage> messages, String sys) async* {
    final req = http.Request('POST', Uri.parse('${provider.baseUrl}/v1/messages'));
    req.headers['Content-Type'] = 'application/json';
    req.headers['x-api-key'] = provider.apiKey;
    req.headers['anthropic-version'] = '2023-06-01';
    req.body = jsonEncode({
      'model': provider.selectedModel,
      'max_tokens': 4096,
      'system': sys,
      'stream': true,
      'messages': messages.map((m) => m.toApiMap()).toList(),
    });

    final client = http.Client();
    try {
      final response = await client.send(req).timeout(const Duration(seconds: 30));
      if (response.statusCode != 200) {
        throw Exception('Anthropic error ${response.statusCode}');
      }
      await for (final line in response.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter())) {
        if (!line.startsWith('data: ')) continue;
        try {
          final json = jsonDecode(line.substring(6));
          if (json['type'] == 'content_block_delta') {
            final text = json['delta']?['text'];
            if (text is String && text.isNotEmpty) yield text;
          }
        } catch (_) {}
      }
    } finally {
      client.close();
    }
  }

  // ── Google Gemini streaming ──
  Stream<String> _streamGoogle(
      AIProvider provider, List<ChatMessage> messages, String sys) async* {
    final model = provider.selectedModel;
    final url =
        '${provider.baseUrl}/models/$model:streamGenerateContent?key=${provider.apiKey}';

    // Convert messages to Gemini format (merge consecutive same-role)
    final rawContents = messages.map((m) => {
      'role': m.role == 'assistant' ? 'model' : 'user',
      'parts': [{'text': m.content}],
    }).toList();

    // Gemini requires alternating user/model — merge duplicates
    final contents = <Map<String, dynamic>>[];
    for (final c in rawContents) {
      if (contents.isNotEmpty && contents.last['role'] == c['role']) {
        final lastParts = contents.last['parts'] as List;
        final newParts = c['parts'] as List;
        contents.last['parts'] = [...lastParts, ...newParts];
      } else {
        contents.add(Map<String, dynamic>.from(c));
      }
    }

    // Ensure conversation starts with user
    if (contents.isNotEmpty && contents.first['role'] == 'model') {
      contents.removeAt(0);
    }

    final req = http.Request('POST', Uri.parse(url));
    req.headers['Content-Type'] = 'application/json';
    req.body = jsonEncode({
      'system_instruction': {'parts': [{'text': sys}]},
      'contents': contents,
      'generationConfig': {
        'maxOutputTokens': 4096,
        'temperature': 0.7,
      },
    });

    final client = http.Client();
    try {
      final response = await client.send(req).timeout(const Duration(seconds: 30));
      if (response.statusCode != 200) {
        final body = await response.stream.bytesToString();
        throw Exception('Gemini error ${response.statusCode}: $body');
      }

      // Gemini returns a JSON array streamed in chunks — buffer and extract text
      final buffer = StringBuffer();
      final emittedTexts = <String>{};

      await for (final chunk in response.stream.transform(utf8.decoder)) {
        buffer.write(chunk);
        final text = buffer.toString();
        final matches = RegExp(r'"text":\s*"((?:[^"\\]|\\.)*)"').allMatches(text);
        for (final m in matches) {
          final raw = m.group(1) ?? '';
          if (raw.isNotEmpty && !emittedTexts.contains(raw)) {
            emittedTexts.add(raw);
            final decoded = raw
                .replaceAll(r'\n', '\n')
                .replaceAll(r'\"', '"')
                .replaceAll(r'\\', '\\');
            yield decoded;
          }
        }
      }
    } finally {
      client.close();
    }
  }

  // ── Fetch available models from a provider ──
  Future<List<String>> fetchModels(AIProvider provider) async {
    try {
      final url = provider.type == AIProviderType.ollama
          ? '${provider.baseUrl}/api/tags'
          : '${provider.baseUrl}/models';
      final res = await http.get(
        Uri.parse(url),
        headers: {'Authorization': 'Bearer ${provider.apiKey}'},
      ).timeout(const Duration(seconds: 10));

      final json = jsonDecode(res.body);
      if (provider.type == AIProviderType.ollama) {
        return (json['models'] as List).map((m) => m['name'].toString()).toList();
      }
      return (json['data'] as List).map((m) => m['id'].toString()).toList();
    } catch (_) {
      return provider.models; // return preset list on error
    }
  }

  // ── Quick connectivity test ──
  Future<bool> testProvider(AIProvider provider) async {
    try {
      final results = <String>[];
      await for (final t in streamChat(provider, [
        ChatMessage(role: 'user', content: 'Hi', timestamp: DateTime.now()),
      ])) {
        results.add(t);
        if (results.length > 3) break;
      }
      return results.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static const _defaultSystemPrompt =
      'You are PowerFiles AI Assistant — an intelligent assistant embedded in the '
      'PowerFiles Android file manager app.\n\n'
      'You help users manage files, write code, analyze storage, and automate tasks.\n'
      'You can suggest file operations, explain code, help organize files, and answer questions.\n\n'
      'When performing file operations:\n'
      '- Always describe what you\'re about to do first\n'
      '- For destructive actions (delete, overwrite), ask for confirmation\n'
      '- Report what was done after each action\n'
      '- Offer to undo if something went wrong\n\n'
      'Respond in a helpful, concise manner. Support Hinglish (Hindi+English mix) if the user writes in it.';
}

final aiService = AIService();
