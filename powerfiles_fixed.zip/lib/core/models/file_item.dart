import 'dart:io';

enum FileType { folder, image, video, audio, document, apk, archive, code, text, unknown }

class FileItem {
  final String name;
  final String path;
  final bool isDirectory;
  final int size;
  final DateTime lastModified;
  final String? mimeType;
  final bool isHidden;
  final bool canRead;
  final bool canWrite;
  final String extension;

  const FileItem({
    required this.name,
    required this.path,
    required this.isDirectory,
    required this.size,
    required this.lastModified,
    this.mimeType,
    this.isHidden = false,
    this.canRead = true,
    this.canWrite = true,
    this.extension = '',
  });

  factory FileItem.fromMap(Map<dynamic, dynamic> map) {
    return FileItem(
      name: map['name'] as String,
      path: map['path'] as String,
      isDirectory: map['isDirectory'] as bool,
      size: (map['size'] as num).toInt(),
      lastModified: DateTime.fromMillisecondsSinceEpoch((map['lastModified'] as num).toInt()),
      mimeType: map['mimeType'] as String?,
      isHidden: map['isHidden'] as bool? ?? false,
      canRead: map['canRead'] as bool? ?? true,
      canWrite: map['canWrite'] as bool? ?? true,
      extension: map['extension'] as String? ?? '',
    );
  }

  FileType get fileType {
    if (isDirectory) return FileType.folder;
    final ext = extension.toLowerCase();
    if (['jpg','jpeg','png','gif','webp','bmp','svg','heic','heif'].contains(ext)) return FileType.image;
    if (['mp4','mkv','avi','mov','wmv','flv','webm','m4v','3gp'].contains(ext)) return FileType.video;
    if (['mp3','wav','flac','aac','ogg','m4a','wma','opus'].contains(ext)) return FileType.audio;
    if (['pdf','doc','docx','xls','xlsx','ppt','pptx','odt','ods'].contains(ext)) return FileType.document;
    if (ext == 'apk') return FileType.apk;
    if (['zip','rar','tar','gz','7z','bz2','xz','tgz'].contains(ext)) return FileType.archive;
    if (['dart','kt','java','py','js','ts','html','css','json','xml','yaml','yml',
         'cpp','c','h','rs','go','php','rb','sh','bash','sql','swift','lua'].contains(ext)) return FileType.code;
    if (['txt','md','log','csv','ini','toml','env','cfg','conf'].contains(ext)) return FileType.text;
    return FileType.unknown;
  }

  String get formattedSize {
    if (size < 1024) return '$size B';
    if (size < 1024 * 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    if (size < 1024 * 1024 * 1024) return '${(size / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(size / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  String get formattedDate {
    final now = DateTime.now();
    final diff = now.difference(lastModified);
    if (diff.inDays == 0) return 'Today';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays} days ago';
    return '${lastModified.day}/${lastModified.month}/${lastModified.year}';
  }

  @override
  bool operator ==(Object other) => other is FileItem && other.path == path;

  @override
  int get hashCode => path.hashCode;
}
