import 'package:flutter/material.dart';
import '../../app/theme.dart';
import '../../core/models/file_item.dart';

class FileIcon extends StatelessWidget {
  final FileType fileType;
  final double size;

  const FileIcon({super.key, required this.fileType, this.size = 36});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: _bgColor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(size * 0.22),
      ),
      child: Icon(_icon, color: _bgColor, size: size * 0.55),
    );
  }

  IconData get _icon {
    switch (fileType) {
      case FileType.folder: return Icons.folder;
      case FileType.image: return Icons.image;
      case FileType.video: return Icons.videocam;
      case FileType.audio: return Icons.music_note;
      case FileType.document: return Icons.description;
      case FileType.apk: return Icons.android;
      case FileType.archive: return Icons.archive;
      case FileType.code: return Icons.code;
      case FileType.text: return Icons.text_snippet;
      default: return Icons.insert_drive_file;
    }
  }

  Color get _bgColor {
    switch (fileType) {
      case FileType.folder: return AppColors.colorFolder;
      case FileType.image: return AppColors.colorImage;
      case FileType.video: return AppColors.colorVideo;
      case FileType.audio: return AppColors.colorAudio;
      case FileType.document: return AppColors.colorDocument;
      case FileType.apk: return AppColors.colorApk;
      case FileType.archive: return AppColors.colorArchive;
      case FileType.code: return AppColors.colorCode;
      case FileType.text: return AppColors.accentCyan;
      default: return AppColors.textSecondary;
    }
  }
}
