import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';
import '../../core/services/ai_service.dart';

class TerminalScreen extends StatefulWidget {
  const TerminalScreen({super.key});
  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen>
    with SingleTickerProviderStateMixin {
  static const _channel = MethodChannel('com.powerfiles/terminal');

  final _outputCtrl = ScrollController();
  final _inputCtrl = TextEditingController();
  final _inputFocus = FocusNode();
  final List<_TermLine> _lines = [];
  final List<String> _history = [];
  int _historyIndex = -1;
  String _cwd = '/storage/emulated/0';
  bool _isRunning = false;
  int _activeTab = 0;

  final _colorSchemes = {
    'Dracula': const _ColorScheme(bg: Color(0xFF282A36), fg: Color(0xFFF8F8F2)),
    'Tokyo Night': const _ColorScheme(bg: Color(0xFF1A1B26), fg: Color(0xFFA9B1D6)),
    'Monokai': const _ColorScheme(bg: Color(0xFF272822), fg: Color(0xFFF8F8F2)),
    'Gruvbox': const _ColorScheme(bg: Color(0xFF282828), fg: Color(0xFFEBDBB2)),
    'OLED Black': const _ColorScheme(bg: Color(0xFF000000), fg: Color(0xFFFFFFFF)),
  };
  String _scheme = 'Tokyo Night';
  double _fontSize = 13.0;

  @override
  void initState() {
    super.initState();
    _printWelcome();
  }

  @override
  void dispose() {
    _outputCtrl.dispose();
    _inputCtrl.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  void _printWelcome() {
    _addLine('PowerFiles Terminal v1.0', color: AppColors.accentCyan, bold: true);
    _addLine('Type commands below. PowerFiles custom commands: pf-ai, pf-storage, pf-scan');
    _addLine('');
    _printPrompt();
  }

  void _printPrompt() {
    _addLine('\$ ', color: AppColors.accentGreen, isPrompt: true);
  }

  void _addLine(String text, {Color? color, bool bold = false, bool isPrompt = false}) {
    setState(() => _lines.add(_TermLine(
      text: text, color: color, bold: bold, isPrompt: isPrompt,
    )));
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final cs = _colorSchemes[_scheme]!;
    return Scaffold(
      backgroundColor: cs.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bgSecondary,
        title: Row(children: [
          const Icon(Icons.terminal, size: 18, color: AppColors.accentGreen),
          const SizedBox(width: 8),
          Text(_cwd, style: const TextStyle(
            fontFamily: 'monospace', fontSize: 13, color: AppColors.accentGreen,
          ), maxLines: 1, overflow: TextOverflow.ellipsis),
        ]),
        actions: [
          PopupMenuButton(
            icon: const Icon(Icons.palette_outlined),
            itemBuilder: (_) => _colorSchemes.keys.map((k) =>
              PopupMenuItem(value: k, child: Row(children: [
                Container(width: 14, height: 14, color: _colorSchemes[k]!.bg,
                    margin: const EdgeInsets.only(right: 8)),
                Text(k),
              ]))
            ).toList(),
            onSelected: (v) => setState(() => _scheme = v),
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            onPressed: () => setState(() => _fontSize = (_fontSize + 1).clamp(10, 20)),
          ),
          IconButton(
            icon: const Icon(Icons.text_decrease),
            onPressed: () => setState(() => _fontSize = (_fontSize - 1).clamp(10, 20)),
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: () => setState(() { _lines.clear(); _printWelcome(); }),
          ),
        ],
      ),
      body: Column(
        children: [
          // Output area
          Expanded(
            child: GestureDetector(
              onTap: () => _inputFocus.requestFocus(),
              child: Container(
                color: cs.bg,
                child: ListView.builder(
                  controller: _outputCtrl,
                  padding: const EdgeInsets.all(10),
                  itemCount: _lines.length,
                  itemBuilder: (_, i) => _buildLine(_lines[i], cs),
                ),
              ),
            ),
          ),
          // Input row
          Container(
            color: cs.bg,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            child: Row(children: [
              Text('\$ ', style: TextStyle(
                color: AppColors.accentGreen, fontFamily: 'monospace',
                fontSize: _fontSize, fontWeight: FontWeight.bold,
              )),
              Expanded(
                child: TextField(
                  controller: _inputCtrl,
                  focusNode: _inputFocus,
                  autofocus: true,
                  style: TextStyle(
                    color: cs.fg, fontFamily: 'monospace', fontSize: _fontSize,
                  ),
                  cursorColor: AppColors.accentGreen,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: EdgeInsets.zero,
                  ),
                  onSubmitted: (_) => _runCommand(),
                ),
              ),
              if (_isRunning)
                GestureDetector(
                  onTap: () => setState(() => _isRunning = false),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.accentRed.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text('CTRL+C', style: TextStyle(
                      fontSize: 10, color: AppColors.accentRed, fontFamily: 'monospace',
                    )),
                  ),
                )
              else
                GestureDetector(
                  onTap: _runCommand,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.accentGreen.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Icon(Icons.send, size: 16, color: AppColors.accentGreen),
                  ),
                ),
            ]),
          ),
          // Shortcut bar
          _buildShortcutBar(cs),
        ],
      ),
    );
  }

  Widget _buildLine(_TermLine line, _ColorScheme cs) {
    return Text(
      line.text,
      style: TextStyle(
        color: line.color ?? cs.fg,
        fontFamily: 'monospace',
        fontSize: _fontSize,
        fontWeight: line.bold ? FontWeight.bold : FontWeight.normal,
        height: 1.4,
      ),
    );
  }

  Widget _buildShortcutBar(_ColorScheme cs) {
    final shortcuts = ['Tab', 'Ctrl', '↑', '↓', '←', '→', '|', '/', '-', '~'];
    return Container(
      height: 38,
      color: AppColors.bgSecondary,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        children: shortcuts.map((s) => GestureDetector(
          onTap: () => _shortcutTap(s),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: AppColors.bgTertiary,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: AppColors.border),
            ),
            child: Center(child: Text(s, style: const TextStyle(
              fontFamily: 'monospace', fontSize: 13, color: AppColors.textPrimary,
            ))),
          ),
        )).toList(),
      ),
    );
  }

  void _shortcutTap(String key) {
    switch (key) {
      case '↑': _historyUp(); break;
      case '↓': _historyDown(); break;
      case 'Tab':
        final text = _inputCtrl.text;
        _inputCtrl.text = '$text    ';
        break;
      default:
        final prev = _inputCtrl.text;
        _inputCtrl.text = prev + key;
        _inputCtrl.selection = TextSelection.fromPosition(
            TextPosition(offset: _inputCtrl.text.length));
    }
  }

  void _historyUp() {
    if (_history.isEmpty) return;
    setState(() {
      _historyIndex = (_historyIndex + 1).clamp(0, _history.length - 1);
      _inputCtrl.text = _history[_historyIndex];
    });
  }

  void _historyDown() {
    setState(() {
      _historyIndex = (_historyIndex - 1).clamp(-1, _history.length - 1);
      _inputCtrl.text = _historyIndex < 0 ? '' : _history[_historyIndex];
    });
  }

  Future<void> _runCommand() async {
    final cmd = _inputCtrl.text.trim();
    if (cmd.isEmpty) return;

    _inputCtrl.clear();
    _history.insert(0, cmd);
    _historyIndex = -1;

    _addLine('\$ $cmd', color: AppColors.accentGreen, bold: true);
    setState(() => _isRunning = true);

    try {
      // PowerFiles custom commands
      if (cmd.startsWith('pf-')) {
        await _handleCustomCommand(cmd);
      } else if (cmd.startsWith('cd ')) {
        await _handleCd(cmd.substring(3).trim());
      } else if (cmd == 'clear' || cmd == 'cls') {
        setState(() => _lines.clear());
      } else {
        // Run via MethodChannel
        final result = await _channel.invokeMethod('runCommand', {
          'command': cmd,
          'workDir': _cwd,
        }) as Map;
        final output = result['output'] as String? ?? '';
        final exitCode = result['exitCode'] as int? ?? 0;
        if (output.isNotEmpty) _addOutputLines(output);
        if (exitCode != 0) {
          _addLine('[exit $exitCode]', color: AppColors.accentRed);
        }
      }
    } catch (e) {
      _addLine('Error: $e', color: AppColors.accentRed);
    }

    setState(() => _isRunning = false);
    _printPrompt();
  }

  void _addOutputLines(String output) {
    for (final line in output.split('\n')) {
      Color? color;
      if (line.contains('error') || line.contains('Error') || line.startsWith('E ')) {
        color = AppColors.accentRed;
      } else if (line.contains('warning') || line.startsWith('W ')) {
        color = AppColors.accentAmber;
      }
      _addLine(line, color: color);
    }
  }

  Future<void> _handleCd(String path) async {
    String newPath;
    if (path.startsWith('/')) {
      newPath = path;
    } else if (path == '..') {
      final parts = _cwd.split('/');
      parts.removeLast();
      newPath = parts.isEmpty ? '/' : parts.join('/');
    } else if (path == '~') {
      newPath = '/storage/emulated/0';
    } else {
      newPath = '$_cwd/$path';
    }

    try {
      final exists = await fileService.exists(newPath);
      if (exists) {
        setState(() => _cwd = newPath);
      } else {
        _addLine('cd: $newPath: No such file or directory', color: AppColors.accentRed);
      }
    } catch (e) {
      _addLine('cd: $e', color: AppColors.accentRed);
    }
  }

  Future<void> _handleCustomCommand(String cmd) async {
    if (cmd == 'pf-storage') {
      _addLine('Fetching storage info...', color: AppColors.accentCyan);
      final stats = await fileService.getStorageStats();
      final used = stats['usedBytes'] as int;
      final total = stats['totalBytes'] as int;
      _addLine('Storage: ${_fmt(used)} used / ${_fmt(total)} total (${stats['percentUsed']}%)',
          color: AppColors.accentGreen);
    } else if (cmd == 'pf-scan') {
      _addLine('Starting scan...', color: AppColors.accentCyan);
      final root = await fileService.getStorageRoot();
      final junk = await fileService.getJunkFiles(root);
      _addLine('Found ${junk.length} junk files', color: AppColors.accentAmber);
      final large = await fileService.getLargeFiles(root, minSizeMB: 50);
      _addLine('Found ${large.length} files over 50MB', color: AppColors.accentBlue);
    } else if (cmd.startsWith('pf-open ')) {
      final path = cmd.substring(8).trim();
      if (path.isEmpty) {
        _addLine('Usage: pf-open <file>', color: AppColors.accentRed);
      } else {
        final ok = await fileService.exists(path);
        if (!ok) {
          _addLine('pf-open: $path: No such file', color: AppColors.accentRed);
        } else {
          try {
            await fileService.openFile(path);
            _addLine('Opened $path', color: AppColors.accentGreen);
          } catch (e) {
            _addLine('pf-open: $e', color: AppColors.accentRed);
          }
        }
      }
    } else if (cmd.startsWith('pf-ai ')) {
      final prompt = cmd.substring(6).trim();
      if (prompt.isEmpty) {
        _addLine('Usage: pf-ai <message>', color: AppColors.accentRed);
      } else {
        if (aiService.providers.isEmpty) await aiService.init();
        final provider = aiService.activeProvider;
        if (provider == null) {
          _addLine('No AI provider configured. Set one in Settings > AI Providers.',
              color: AppColors.accentRed);
        } else {
          _addLine('Thinking...', color: AppColors.accentCyan);
          try {
            final buffer = StringBuffer();
            await for (final chunk in aiService.streamChat(
              provider,
              [ChatMessage(role: 'user', content: prompt, timestamp: DateTime.now())],
            )) {
              buffer.write(chunk);
            }
            _addOutputLines(buffer.toString());
          } catch (e) {
            _addLine('pf-ai: $e', color: AppColors.accentRed);
          }
        }
      }
    } else {
      _addLine('Unknown command: $cmd', color: AppColors.accentRed);
      _addLine('Available: pf-storage, pf-scan, pf-open <file>, pf-ai <message>',
          color: AppColors.textSecondary);
    }
  }

  String _fmt(int bytes) {
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_outputCtrl.hasClients) {
        _outputCtrl.animateTo(
          _outputCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 100),
          curve: Curves.easeOut,
        );
      }
    });
  }
}

class _TermLine {
  final String text;
  final Color? color;
  final bool bold;
  final bool isPrompt;
  const _TermLine({required this.text, this.color, this.bold = false, this.isPrompt = false});
}

class _ColorScheme {
  final Color bg;
  final Color fg;
  const _ColorScheme({required this.bg, required this.fg});
}
