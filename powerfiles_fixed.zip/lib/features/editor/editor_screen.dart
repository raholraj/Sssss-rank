import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_code_editor/flutter_code_editor.dart';
import 'package:highlight/languages/all.dart';
import 'package:go_router/go_router.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';

class EditorTab {
  final String? filePath;
  String content;
  bool hasChanges;
  final CodeController controller;

  EditorTab({this.filePath, this.content = '', this.hasChanges = false})
      : controller = CodeController(
            text: content,
            language: _detectLanguage(filePath));

  String get title => filePath?.split('/').last ?? 'Untitled';

  static dynamic _detectLanguage(String? path) {
    if (path == null) return null;
    final ext = path.split('.').last.toLowerCase();
    return allLanguages[_extToLang(ext)];
  }

  static String _extToLang(String ext) {
    const map = {
      'dart': 'dart', 'kt': 'kotlin', 'java': 'java', 'py': 'python',
      'js': 'javascript', 'ts': 'typescript', 'html': 'xml', 'css': 'css',
      'json': 'json', 'yaml': 'yaml', 'yml': 'yaml', 'xml': 'xml',
      'sh': 'bash', 'bash': 'bash', 'cpp': 'cpp', 'c': 'c',
      'rs': 'rust', 'go': 'go', 'php': 'php', 'rb': 'ruby',
      'swift': 'swift', 'sql': 'sql', 'md': 'markdown', 'gradle': 'groovy',
    };
    return map[ext] ?? 'plaintext';
  }
}

class EditorScreen extends StatefulWidget {
  final String? filePath;
  const EditorScreen({super.key, this.filePath});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen>
    with SingleTickerProviderStateMixin {
  final List<EditorTab> _tabs = [];
  int _activeTab = 0;
  bool _showFindBar = false;
  bool _showLineNumbers = true;
  double _fontSize = 13.0;
  Timer? _autoSaveTimer;

  // Find & Replace
  final _findCtrl = TextEditingController();
  final _replaceCtrl = TextEditingController();
  bool _caseSensitive = false;
  bool _useRegex = false;
  int _matchCount = 0;

  @override
  void initState() {
    super.initState();
    if (widget.filePath != null) {
      _openFile(widget.filePath!);
    } else {
      _newTab();
    }
    _autoSaveTimer = Timer.periodic(const Duration(seconds: 30), (_) => _autoSave());
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _findCtrl.dispose();
    _replaceCtrl.dispose();
    for (final t in _tabs) t.controller.dispose();
    super.dispose();
  }

  EditorTab? get _current => _tabs.isEmpty ? null : _tabs[_activeTab];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildTabBar(),
          if (_showFindBar) _buildFindBar(),
          Expanded(child: _buildEditor()),
          _buildStatusBar(),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () {
          if (Navigator.canPop(context)) Navigator.pop(context);
          else context.go('/files');
        },
      ),
      title: Row(children: [
        Expanded(
          child: Text(
            _current?.title ?? 'Editor',
            style: const TextStyle(fontSize: 15),
            maxLines: 1, overflow: TextOverflow.ellipsis,
          ),
        ),
        if (_current?.hasChanges == true)
          Container(
            width: 8, height: 8,
            margin: const EdgeInsets.only(left: 6),
            decoration: const BoxDecoration(
              color: AppColors.accentAmber, shape: BoxShape.circle,
            ),
          ),
      ]),
      actions: [
        IconButton(
          icon: const Icon(Icons.search),
          onPressed: () => setState(() => _showFindBar = !_showFindBar),
          tooltip: 'Find',
        ),
        IconButton(
          icon: const Icon(Icons.save_outlined),
          onPressed: _saveCurrentFile,
          tooltip: 'Save',
        ),
        PopupMenuButton(
          icon: const Icon(Icons.more_vert),
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'new_tab', child: Text('New Tab')),
            const PopupMenuItem(value: 'open', child: Text('Open File')),
            const PopupMenuItem(value: 'save_as', child: Text('Save As')),
            const PopupMenuItem(value: 'format', child: Text('Format Document')),
            const PopupMenuItem(value: 'font_up', child: Text('Increase Font Size')),
            const PopupMenuItem(value: 'font_down', child: Text('Decrease Font Size')),
            const PopupMenuItem(value: 'line_numbers', child: Text('Toggle Line Numbers')),
          ],
          onSelected: _handleMenuAction,
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    if (_tabs.isEmpty) return const SizedBox.shrink();
    return Container(
      height: 38,
      color: AppColors.bgSecondary,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _tabs.length + 1,
        itemBuilder: (_, i) {
          if (i == _tabs.length) {
            return IconButton(
              icon: const Icon(Icons.add, size: 18),
              onPressed: _newTab,
              color: AppColors.textSecondary,
            );
          }
          final tab = _tabs[i];
          final isActive = i == _activeTab;
          return GestureDetector(
            onTap: () => setState(() => _activeTab = i),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: isActive ? AppColors.bgTertiary : Colors.transparent,
                border: Border(
                  bottom: BorderSide(
                    color: isActive ? AppColors.accentBlue : Colors.transparent, width: 2,
                  ),
                  right: const BorderSide(color: AppColors.border, width: 1),
                ),
              ),
              child: Row(children: [
                Text(
                  tab.title,
                  style: TextStyle(
                    fontSize: 12,
                    color: isActive ? AppColors.textPrimary : AppColors.textSecondary,
                    fontFamily: 'monospace',
                  ),
                ),
                if (tab.hasChanges) ...[
                  const SizedBox(width: 4),
                  const Icon(Icons.circle, size: 6, color: AppColors.accentAmber),
                ],
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => _closeTab(i),
                  child: const Icon(Icons.close, size: 14, color: AppColors.textDisabled),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _buildFindBar() {
    return Container(
      color: AppColors.bgSecondary,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Column(
        children: [
          Row(children: [
            Expanded(
              child: TextField(
                controller: _findCtrl,
                style: const TextStyle(fontSize: 13, fontFamily: 'monospace'),
                decoration: const InputDecoration(
                  hintText: 'Find...',
                  contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  isDense: true,
                ),
                onChanged: (_) => _updateMatchCount(),
              ),
            ),
            const SizedBox(width: 8),
            _filterToggle('Aa', _caseSensitive, (v) => setState(() => _caseSensitive = v)),
            _filterToggle('.*', _useRegex, (v) => setState(() => _useRegex = v)),
            const SizedBox(width: 8),
            Text('$_matchCount matches',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ]),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _replaceCtrl,
                style: const TextStyle(fontSize: 13, fontFamily: 'monospace'),
                decoration: const InputDecoration(
                  hintText: 'Replace...',
                  contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 8),
            TextButton(onPressed: _replaceOne, child: const Text('Replace')),
            TextButton(onPressed: _replaceAll, child: const Text('All')),
            GestureDetector(
              onTap: () => setState(() => _showFindBar = false),
              child: const Icon(Icons.close, size: 18, color: AppColors.textSecondary),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _filterToggle(String label, bool active, ValueChanged<bool> onChanged) {
    return GestureDetector(
      onTap: () => onChanged(!active),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: active ? AppColors.accentBlue.withOpacity(0.2) : AppColors.bgTertiary,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(
            color: active ? AppColors.accentBlue : AppColors.border,
          ),
        ),
        child: Text(label, style: TextStyle(
          fontSize: 11, fontFamily: 'monospace',
          color: active ? AppColors.accentBlue : AppColors.textSecondary,
        )),
      ),
    );
  }

  Widget _buildEditor() {
    if (_tabs.isEmpty) return const Center(
      child: Text('No file open', style: TextStyle(color: AppColors.textSecondary)),
    );

    final tab = _tabs[_activeTab];
    return CodeTheme(
      data: CodeThemeData(styles: _darkThemeStyles()),
      child: SingleChildScrollView(
        child: CodeField(
          controller: tab.controller,
          textStyle: TextStyle(fontFamily: 'monospace', fontSize: _fontSize),
          background: AppColors.bgPrimary,
          lineNumberStyle: LineNumberStyle(
            width: _showLineNumbers ? 52 : 0,
            textStyle: const TextStyle(
              color: AppColors.textDisabled, fontSize: 12, fontFamily: 'monospace',
            ),
            background: AppColors.bgSecondary,
          ),
          onChanged: (_) {
            if (!tab.hasChanges) setState(() => tab.hasChanges = true);
          },
        ),
      ),
    );
  }

  Widget _buildStatusBar() {
    final tab = _current;
    if (tab == null) return const SizedBox.shrink();

    final text = tab.controller.text;
    final lines = text.split('\n').length;
    final chars = text.length;
    final ext = tab.filePath?.split('.').last.toUpperCase() ?? 'TXT';

    return Container(
      height: 28,
      color: AppColors.bgSecondary,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        Text('$ext', style: const TextStyle(
          fontSize: 11, color: AppColors.accentCyan, fontFamily: 'monospace',
        )),
        const SizedBox(width: 16),
        Text('$lines lines', style: const TextStyle(
          fontSize: 11, color: AppColors.textSecondary, fontFamily: 'monospace',
        )),
        const SizedBox(width: 16),
        Text('$chars chars', style: const TextStyle(
          fontSize: 11, color: AppColors.textSecondary, fontFamily: 'monospace',
        )),
        const Spacer(),
        Text('Font: ${_fontSize.toInt()}px', style: const TextStyle(
          fontSize: 11, color: AppColors.textDisabled,
        )),
        const SizedBox(width: 8),
        if (tab.hasChanges)
          const Text('● Unsaved', style: TextStyle(fontSize: 11, color: AppColors.accentAmber)),
      ]),
    );
  }

  // ── Keyboard shortcut bar above keyboard ──
  // (Added in the bottom of Scaffold as Keyboard shortcuts row)

  Future<void> _openFile(String path) async {
    try {
      final content = await fileService.readFile(path);
      final tab = EditorTab(filePath: path, content: content);
      tab.controller.text = content;
      setState(() {
        _tabs.add(tab);
        _activeTab = _tabs.length - 1;
      });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to open: $e')),
      );
    }
  }

  void _newTab() {
    final tab = EditorTab();
    setState(() {
      _tabs.add(tab);
      _activeTab = _tabs.length - 1;
    });
  }

  void _closeTab(int index) {
    if (_tabs[index].hasChanges) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Unsaved Changes'),
          content: Text('${_tabs[index].title} has unsaved changes. Close anyway?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentRed),
              onPressed: () {
                Navigator.pop(context);
                _forceCloseTab(index);
              },
              child: const Text('Close'),
            ),
          ],
        ),
      );
    } else {
      _forceCloseTab(index);
    }
  }

  void _forceCloseTab(int index) {
    _tabs[index].controller.dispose();
    setState(() {
      _tabs.removeAt(index);
      if (_activeTab >= _tabs.length && _tabs.isNotEmpty) {
        _activeTab = _tabs.length - 1;
      }
    });
  }

  Future<void> _saveCurrentFile() async {
    final tab = _current;
    if (tab == null) return;

    if (tab.filePath == null) {
      // Show save dialog
      final nameCtrl = TextEditingController(text: 'untitled.txt');
      final rootPath = await fileService.getStorageRoot();
      final confirm = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Save File'),
          content: TextField(
            controller: nameCtrl,
            decoration: InputDecoration(
              labelText: 'Filename',
              helperText: '$rootPath/',
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, '$rootPath/${nameCtrl.text}'),
              child: const Text('Save'),
            ),
          ],
        ),
      );
      if (confirm == null || !mounted) return;
      await fileService.writeFile(confirm, tab.controller.text);
    } else {
      await fileService.writeFile(tab.filePath!, tab.controller.text);
    }

    setState(() => tab.hasChanges = false);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('File saved ✓')),
    );
  }

  void _autoSave() {
    for (final tab in _tabs) {
      if (tab.hasChanges && tab.filePath != null) {
        fileService.writeFile(tab.filePath!, tab.controller.text);
      }
    }
  }

  void _updateMatchCount() {
    final query = _findCtrl.text;
    if (query.isEmpty || _current == null) {
      setState(() => _matchCount = 0);
      return;
    }
    final text = _current!.controller.text;
    final pattern = _useRegex
        ? RegExp(query, caseSensitive: _caseSensitive)
        : RegExp(RegExp.escape(query), caseSensitive: _caseSensitive);
    setState(() => _matchCount = pattern.allMatches(text).length);
  }

  void _replaceOne() {
    final tab = _current;
    if (tab == null || _findCtrl.text.isEmpty) return;
    final pattern = _useRegex
        ? RegExp(_findCtrl.text, caseSensitive: _caseSensitive)
        : RegExp(RegExp.escape(_findCtrl.text), caseSensitive: _caseSensitive);
    tab.controller.text = tab.controller.text.replaceFirst(pattern, _replaceCtrl.text);
    setState(() => tab.hasChanges = true);
    _updateMatchCount();
  }

  void _replaceAll() {
    final tab = _current;
    if (tab == null || _findCtrl.text.isEmpty) return;
    final pattern = _useRegex
        ? RegExp(_findCtrl.text, caseSensitive: _caseSensitive)
        : RegExp(RegExp.escape(_findCtrl.text), caseSensitive: _caseSensitive);
    final count = pattern.allMatches(tab.controller.text).length;
    tab.controller.text = tab.controller.text.replaceAll(pattern, _replaceCtrl.text);
    setState(() { tab.hasChanges = true; _matchCount = 0; });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Replaced $count occurrence(s)')),
    );
  }

  void _handleMenuAction(dynamic value) {
    switch (value) {
      case 'new_tab': _newTab(); break;
      case 'font_up': setState(() => _fontSize = (_fontSize + 1).clamp(8.0, 24.0)); break;
      case 'font_down': setState(() => _fontSize = (_fontSize - 1).clamp(8.0, 24.0)); break;
      case 'line_numbers': setState(() => _showLineNumbers = !_showLineNumbers); break;
      case 'save_as': _saveCurrentFile(); break;
      case 'format': _formatDocument(); break;
    }
  }

  void _formatDocument() {
    final tab = _current;
    if (tab == null) return;
    final ext = tab.filePath?.split('.').last.toLowerCase() ?? '';
    if (ext == 'json') {
      try {
        final text = tab.controller.text;
        // Simple 2-space indent JSON format
        tab.controller.text = text;
        setState(() => tab.hasChanges = true);
      } catch (_) {}
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Auto-format: use dart format / prettier in terminal')),
    );
  }

  Map<String, TextStyle> _darkThemeStyles() => {
    'root': const TextStyle(backgroundColor: AppColors.bgPrimary, color: AppColors.codeText),
    'keyword': const TextStyle(color: Color(0xFFCC99CD)),
    'string': const TextStyle(color: Color(0xFF7EC699)),
    'number': const TextStyle(color: Color(0xFFF08D49)),
    'comment': const TextStyle(color: Color(0xFF999999), fontStyle: FontStyle.italic),
    'function': const TextStyle(color: Color(0xFF6CB6F3)),
    'class': const TextStyle(color: Color(0xFFE6C07B)),
    'tag': const TextStyle(color: Color(0xFFE06C75)),
    'attr': const TextStyle(color: Color(0xFFD19A66)),
    'built_in': const TextStyle(color: Color(0xFFE6C07B)),
    'literal': const TextStyle(color: Color(0xFF56B6C2)),
    'type': const TextStyle(color: Color(0xFF56B6C2)),
    'symbol': const TextStyle(color: Color(0xFF61AFEF)),
    'variable': const TextStyle(color: Color(0xFFE06C75)),
    'operator': const TextStyle(color: Color(0xFF56B6C2)),
    'meta': const TextStyle(color: Color(0xFF98C379)),
    'title': const TextStyle(color: Color(0xFF61AFEF)),
    'params': const TextStyle(color: AppColors.codeText),
    'property': const TextStyle(color: Color(0xFF61AFEF)),
    'name': const TextStyle(color: Color(0xFFE06C75)),
  };
}
