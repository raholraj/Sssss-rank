import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/theme.dart';
import '../../core/models/file_item.dart';
import '../../core/services/file_service.dart';
import '../../shared/widgets/file_icon.dart';
import 'file_browser_provider.dart';
import 'file_preview_sheet.dart';
import 'file_context_menu.dart';

class FileBrowserScreen extends ConsumerStatefulWidget {
  const FileBrowserScreen({super.key});

  @override
  ConsumerState<FileBrowserScreen> createState() => _FileBrowserScreenState();
}

class _FileBrowserScreenState extends ConsumerState<FileBrowserScreen> {
  final _scrollController = ScrollController();
  bool _showHidden = false;
  bool _isGridView = false;
  Set<String> _selectedPaths = {};
  bool _isSelectionMode = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(fileBrowserProvider.notifier).init();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(fileBrowserProvider);

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: _buildAppBar(state),
      body: Column(
        children: [
          _buildBreadcrumbs(state),
          Expanded(
            child: state.isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.accentBlue))
                : state.error != null
                    ? _buildError(state.error!)
                    : state.files.isEmpty
                        ? _buildEmpty()
                        : _isGridView ? _buildGrid(state.files) : _buildList(state.files),
          ),
        ],
      ),
      floatingActionButton: _isSelectionMode ? null : FloatingActionButton(
        onPressed: () => _showCreateMenu(context, state.currentPath),
        child: const Icon(Icons.add),
        backgroundColor: AppColors.accentBlue,
      ),
      bottomSheet: _isSelectionMode ? _buildSelectionBar() : null,
    );
  }

  PreferredSizeWidget _buildAppBar(FileBrowserState state) {
    if (_isSelectionMode) {
      return AppBar(
        backgroundColor: AppColors.accentBlue.withOpacity(0.15),
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.textPrimary),
          onPressed: () => setState(() { _isSelectionMode = false; _selectedPaths.clear(); }),
        ),
        title: Text('${_selectedPaths.length} selected',
            style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
            icon: const Icon(Icons.select_all),
            onPressed: () => setState(() => _selectedPaths = state.files.map((f) => f.path).toSet()),
          ),
        ],
      );
    }

    return AppBar(
      leading: state.canGoBack
          ? IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => ref.read(fileBrowserProvider.notifier).goBack(),
            )
          : const SizedBox.shrink(),
      title: Text(
        state.currentPath.split('/').last.isEmpty ? 'Storage' : state.currentPath.split('/').last,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
      actions: [
        IconButton(
          icon: Icon(_showHidden ? Icons.visibility_off : Icons.visibility,
              color: _showHidden ? AppColors.accentCyan : null),
          onPressed: () {
            setState(() => _showHidden = !_showHidden);
            ref.read(fileBrowserProvider.notifier).loadDirectory(state.currentPath, showHidden: _showHidden);
          },
          tooltip: _showHidden ? 'Hide hidden files' : 'Show hidden files',
        ),
        IconButton(
          icon: Icon(_isGridView ? Icons.list : Icons.grid_view),
          onPressed: () => setState(() => _isGridView = !_isGridView),
        ),
        PopupMenuButton(
          icon: const Icon(Icons.more_vert),
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'sort', child: Text('Sort by...')),
            const PopupMenuItem(value: 'select', child: Text('Select all')),
            const PopupMenuItem(value: 'new_folder', child: Text('New folder')),
            const PopupMenuItem(value: 'terminal', child: Text('Open Terminal here')),
          ],
          onSelected: (v) => _handleMenuAction(v, state.currentPath),
        ),
      ],
    );
  }

  Widget _buildBreadcrumbs(FileBrowserState state) {
    final parts = state.currentPath.split('/').where((p) => p.isNotEmpty).toList();
    final paths = <String>[];
    String current = '';
    for (final p in parts) {
      current += '/$p';
      paths.add(current);
    }

    return Container(
      height: 40,
      color: AppColors.bgSecondary,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        children: [
          _breadcrumbChip('/', '/storage', () => ref.read(fileBrowserProvider.notifier).loadDirectory(
              '/storage/emulated/0')),
          ...paths.asMap().entries.map((entry) {
            final i = entry.key;
            final path = entry.value;
            final label = path.split('/').last;
            return Row(children: [
              const Icon(Icons.chevron_right, size: 14, color: AppColors.textDisabled),
              _breadcrumbChip(label, path,
                  () => ref.read(fileBrowserProvider.notifier).loadDirectory(path)),
            ]);
          }),
        ],
      ),
    );
  }

  Widget _breadcrumbChip(String label, String path, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(
          color: AppColors.bgTertiary,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(label, style: const TextStyle(
          fontSize: 12, color: AppColors.accentCyan, fontFamily: 'monospace',
        )),
      ),
    );
  }

  Widget _buildList(List<FileItem> files) {
    return ListView.builder(
      controller: _scrollController,
      itemCount: files.length,
      itemBuilder: (context, index) {
        final file = files[index];
        final isSelected = _selectedPaths.contains(file.path);
        return _FileListTile(
          file: file,
          isSelected: isSelected,
          isSelectionMode: _isSelectionMode,
          onTap: () => _handleFileTap(file),
          onLongPress: () => _handleFileLongPress(file),
          onSelect: (v) => _toggleSelection(file.path, v),
        );
      },
    );
  }

  Widget _buildGrid(List<FileItem> files) {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 0.85,
      ),
      itemCount: files.length,
      itemBuilder: (context, index) {
        final file = files[index];
        return _FileGridTile(
          file: file,
          isSelected: _selectedPaths.contains(file.path),
          onTap: () => _handleFileTap(file),
          onLongPress: () => _handleFileLongPress(file),
        );
      },
    );
  }

  Widget _buildError(String error) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 48, color: AppColors.accentRed),
          const SizedBox(height: 12),
          Text(error, style: const TextStyle(color: AppColors.textSecondary), textAlign: TextAlign.center),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () => ref.read(fileBrowserProvider.notifier).refresh(),
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_open, size: 64, color: AppColors.textDisabled),
          const SizedBox(height: 12),
          const Text('Folder is empty', style: TextStyle(color: AppColors.textSecondary, fontSize: 16)),
        ],
      ),
    );
  }

  Widget _buildSelectionBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
      decoration: const BoxDecoration(
        color: AppColors.bgSecondary,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _selectionAction(Icons.content_copy, 'Copy', () => _copySelected()),
          _selectionAction(Icons.content_cut, 'Move', () => _moveSelected()),
          _selectionAction(Icons.delete_outline, 'Delete', () => _deleteSelected(), color: AppColors.accentRed),
          _selectionAction(Icons.share, 'Share', () {}),
          _selectionAction(Icons.archive_outlined, 'Zip', () {}),
          _selectionAction(Icons.info_outline, 'Info', () {}),
        ],
      ),
    );
  }

  Widget _selectionAction(IconData icon, String label, VoidCallback onTap, {Color? color}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 10, color: color ?? AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }

  void _handleFileTap(FileItem file) {
    if (_isSelectionMode) {
      _toggleSelection(file.path, !_selectedPaths.contains(file.path));
      return;
    }
    if (file.isDirectory) {
      ref.read(fileBrowserProvider.notifier).loadDirectory(file.path, showHidden: _showHidden);
    } else {
      _showFilePreview(file);
    }
  }

  void _handleFileLongPress(FileItem file) {
    if (!_isSelectionMode) {
      setState(() {
        _isSelectionMode = true;
        _selectedPaths = {file.path};
      });
    }
  }

  void _toggleSelection(String path, bool selected) {
    setState(() {
      if (selected) {
        _selectedPaths.add(path);
      } else {
        _selectedPaths.remove(path);
        if (_selectedPaths.isEmpty) _isSelectionMode = false;
      }
    });
  }

  void _showFilePreview(FileItem file) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => FilePreviewSheet(file: file),
    );
  }

  void _showContextMenu(FileItem file) {
    showModalBottomSheet(
      context: context,
      builder: (_) => FileContextMenu(
        file: file,
        onDelete: () => _confirmDelete([file]),
        onRename: () => _showRenameDialog(file),
        onOpenInEditor: () => context.push('/editor', extra: file.path),
        onShare: () => fileService.shareFile(file.path),
        onCopyPath: () {
          // Copy path to clipboard
        },
      ),
    );
  }

  void _showRenameDialog(FileItem file) {
    final controller = TextEditingController(text: file.name);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Rename'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'New name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              await fileService.renameFile(file.path, controller.text);
              if (mounted) {
                Navigator.pop(context);
                ref.read(fileBrowserProvider.notifier).refresh();
              }
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(List<FileItem> files) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Row(children: [
          const Icon(Icons.delete_outline, color: AppColors.accentRed),
          const SizedBox(width: 8),
          const Text('Delete', style: TextStyle(color: AppColors.accentRed)),
        ]),
        content: Text(
          files.length == 1
              ? 'Delete "${files.first.name}"?\nThis will go to Recycle Bin.'
              : 'Delete ${files.length} items?\nThese will go to Recycle Bin.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentRed),
            onPressed: () async {
              Navigator.pop(context);
              for (final f in files) {
                await fileService.deleteFile(f.path);
              }
              if (mounted) {
                setState(() { _isSelectionMode = false; _selectedPaths.clear(); });
                ref.read(fileBrowserProvider.notifier).refresh();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${files.length} item(s) deleted')),
                );
              }
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _deleteSelected() {
    final state = ref.read(fileBrowserProvider);
    final selected = state.files.where((f) => _selectedPaths.contains(f.path)).toList();
    _confirmDelete(selected);
  }

  void _copySelected() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${_selectedPaths.length} items copied to clipboard')),
    );
  }

  void _moveSelected() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Tap destination folder to paste')),
    );
  }

  void _showCreateMenu(BuildContext context, String path) {
    showModalBottomSheet(
      context: context,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.create_new_folder, color: AppColors.accentAmber),
              title: const Text('New Folder'),
              onTap: () { Navigator.pop(context); _showNewFolderDialog(path); },
            ),
            ListTile(
              leading: const Icon(Icons.note_add, color: AppColors.accentBlue),
              title: const Text('New File'),
              onTap: () {
                Navigator.pop(context);
                context.push('/editor', extra: null);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showNewFolderDialog(String path) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('New Folder'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Folder name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              await fileService.createFolder('$path/${controller.text}');
              if (mounted) {
                Navigator.pop(context);
                ref.read(fileBrowserProvider.notifier).refresh();
              }
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _handleMenuAction(String action, String path) {
    switch (action) {
      case 'select':
        setState(() => _isSelectionMode = true);
        break;
      case 'new_folder':
        _showNewFolderDialog(path);
        break;
      case 'terminal':
        context.push('/terminal');
        break;
    }
  }
}

// ── File List Tile ──
class _FileListTile extends StatelessWidget {
  final FileItem file;
  final bool isSelected;
  final bool isSelectionMode;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final ValueChanged<bool> onSelect;

  const _FileListTile({
    required this.file,
    required this.isSelected,
    required this.isSelectionMode,
    required this.onTap,
    required this.onLongPress,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        color: isSelected ? AppColors.accentBlue.withOpacity(0.1) : Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            if (isSelectionMode)
              Checkbox(
                value: isSelected,
                onChanged: (v) => onSelect(v ?? false),
              )
            else
              FileIcon(fileType: file.fileType, size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    file.name,
                    style: const TextStyle(
                      fontSize: 14, color: AppColors.textPrimary, fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    file.isDirectory
                        ? file.formattedDate
                        : '${file.formattedSize} · ${file.formattedDate}',
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            if (!file.isDirectory)
              _typeBadge(file.fileType),
          ],
        ),
      ),
    );
  }

  Widget _typeBadge(FileType type) {
    final color = _typeColor(type);
    final label = _typeLabel(type);
    if (label.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(label, style: TextStyle(fontSize: 9, color: color, fontWeight: FontWeight.w600)),
    );
  }

  Color _typeColor(FileType type) {
    switch (type) {
      case FileType.image: return AppColors.colorImage;
      case FileType.video: return AppColors.colorVideo;
      case FileType.audio: return AppColors.colorAudio;
      case FileType.document: return AppColors.colorDocument;
      case FileType.archive: return AppColors.colorArchive;
      case FileType.apk: return AppColors.colorApk;
      case FileType.code: return AppColors.colorCode;
      default: return AppColors.textSecondary;
    }
  }

  String _typeLabel(FileType type) {
    switch (type) {
      case FileType.image: return 'IMG';
      case FileType.video: return 'VID';
      case FileType.audio: return 'AUD';
      case FileType.document: return 'DOC';
      case FileType.archive: return 'ZIP';
      case FileType.apk: return 'APK';
      case FileType.code: return 'CODE';
      default: return '';
    }
  }
}

class _FileGridTile extends StatelessWidget {
  final FileItem file;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const _FileGridTile({
    required this.file, required this.isSelected,
    required this.onTap, required this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        decoration: BoxDecoration(
          color: isSelected ? AppColors.accentBlue.withOpacity(0.15) : AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? AppColors.accentBlue : AppColors.border,
          ),
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FileIcon(fileType: file.fileType, size: 42),
            const SizedBox(height: 8),
            Text(
              file.name,
              style: const TextStyle(fontSize: 11, color: AppColors.textPrimary),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
            if (!file.isDirectory) ...[
              const SizedBox(height: 2),
              Text(file.formattedSize,
                  style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
            ],
          ],
        ),
      ),
    );
  }
}
