import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/models/file_item.dart';
import '../../core/services/file_service.dart';

class FileBrowserState {
  final List<FileItem> files;
  final String currentPath;
  final List<String> history;
  final bool isLoading;
  final String? error;

  const FileBrowserState({
    this.files = const [],
    this.currentPath = '/storage/emulated/0',
    this.history = const [],
    this.isLoading = false,
    this.error,
  });

  bool get canGoBack => history.isNotEmpty;

  FileBrowserState copyWith({
    List<FileItem>? files,
    String? currentPath,
    List<String>? history,
    bool? isLoading,
    String? error,
  }) => FileBrowserState(
    files: files ?? this.files,
    currentPath: currentPath ?? this.currentPath,
    history: history ?? this.history,
    isLoading: isLoading ?? this.isLoading,
    error: error,
  );
}

class FileBrowserNotifier extends StateNotifier<FileBrowserState> {
  FileBrowserNotifier() : super(const FileBrowserState());

  Future<void> init() async {
    final root = await fileService.getStorageRoot();
    await loadDirectory(root);
  }

  Future<void> loadDirectory(String path, {bool showHidden = false}) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final files = await fileService.listDirectory(path, showHidden: showHidden);
      final newHistory = state.currentPath != path
          ? [...state.history, state.currentPath]
          : state.history;
      state = state.copyWith(
        files: files,
        currentPath: path,
        history: newHistory,
        isLoading: false,
      );
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void goBack() {
    if (state.history.isEmpty) return;
    final prev = state.history.last;
    final newHistory = state.history.sublist(0, state.history.length - 1);
    state = state.copyWith(history: newHistory);
    loadDirectory(prev);
  }

  Future<void> refresh() async {
    await loadDirectory(state.currentPath);
  }
}

final fileBrowserProvider = StateNotifierProvider<FileBrowserNotifier, FileBrowserState>(
  (_) => FileBrowserNotifier(),
);
