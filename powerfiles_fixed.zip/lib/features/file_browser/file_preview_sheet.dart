import 'dart:io';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../app/theme.dart';
import '../../core/models/file_item.dart';
import '../../core/services/file_service.dart';
import '../../shared/widgets/file_icon.dart';

class FilePreviewSheet extends StatefulWidget {
  final FileItem file;
  const FilePreviewSheet({super.key, required this.file});

  @override
  State<FilePreviewSheet> createState() => _FilePreviewSheetState();
}

class _FilePreviewSheetState extends State<FilePreviewSheet> {
  String? _textPreview;
  bool _loadingPreview = false;

  @override
  void initState() {
    super.initState();
    _loadPreview();
  }

  Future<void> _loadPreview() async {
    if (widget.file.fileType == FileType.text || widget.file.fileType == FileType.code) {
      setState(() => _loadingPreview = true);
      try {
        final content = await fileService.readFile(widget.file.path);
        setState(() {
          _textPreview = content.split('\n').take(30).join('\n');
          _loadingPreview = false;
        });
      } catch (_) {
        setState(() => _loadingPreview = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.5, maxChildSize: 0.9, minChildSize: 0.3, expand: false,
      builder: (context, scrollController) => Container(
        decoration: const BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        child: Column(children: [
          Center(child: Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            width: 36, height: 4,
            decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
          )),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              FileIcon(fileType: widget.file.fileType, size: 48),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.file.name, style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
                ), maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(
                  widget.file.isDirectory ? widget.file.path
                      : '${widget.file.formattedSize} · ${widget.file.formattedDate}',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
              ])),
            ]),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              if (!widget.file.isDirectory) ...[
                _action(Icons.edit_outlined, 'Edit', () {
                  Navigator.pop(context);
                  context.push('/editor', extra: widget.file.path);
                }),
                _action(Icons.open_in_new, 'Open', () {
                  fileService.openFile(widget.file.path);
                  Navigator.pop(context);
                }),
                _action(Icons.share, 'Share', () {
                  fileService.shareFile(widget.file.path);
                  Navigator.pop(context);
                }),
              ],
              _action(Icons.info_outline, 'Info', () {}),
              _action(Icons.delete_outline, 'Delete', () => Navigator.pop(context),
                  color: AppColors.accentRed),
            ]),
          ),
          const Divider(height: 1),
          Expanded(child: SingleChildScrollView(
            controller: scrollController,
            padding: const EdgeInsets.all(16),
            child: _buildPreview(),
          )),
        ]),
      ),
    );
  }

  Widget _buildPreview() {
    if (widget.file.isDirectory) return const SizedBox.shrink();
    switch (widget.file.fileType) {
      case FileType.image:
        return ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(File(widget.file.path),
            errorBuilder: (_, __, ___) => Container(
              height: 200, alignment: Alignment.center,
              decoration: BoxDecoration(color: AppColors.bgTertiary, borderRadius: BorderRadius.circular(8)),
              child: const Icon(Icons.broken_image, color: AppColors.textDisabled, size: 48),
            ),
          ),
        );
      case FileType.text:
      case FileType.code:
        if (_loadingPreview) return const Center(child: CircularProgressIndicator(color: AppColors.accentBlue));
        if (_textPreview == null) return const Text('Cannot preview', style: TextStyle(color: AppColors.textSecondary));
        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: AppColors.bgPrimary, borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.border)),
          child: SelectableText(_textPreview!, style: const TextStyle(
            fontFamily: 'monospace', fontSize: 12, color: AppColors.codeText, height: 1.5,
          )),
        );
      default:
        return Column(children: [
          const SizedBox(height: 24),
          FileIcon(fileType: widget.file.fileType, size: 64),
          const SizedBox(height: 16),
          Text('${widget.file.extension.toUpperCase()} File',
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 14)),
          const SizedBox(height: 8),
          Text(widget.file.mimeType ?? 'Unknown type',
              style: const TextStyle(color: AppColors.textDisabled, fontSize: 12)),
        ]);
    }
  }

  Widget _action(IconData icon, String label, VoidCallback onTap, {Color? color}) {
    return InkWell(
      onTap: onTap, borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        child: Column(children: [
          Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 11, color: color ?? AppColors.textSecondary)),
        ]),
      ),
    );
  }
}
