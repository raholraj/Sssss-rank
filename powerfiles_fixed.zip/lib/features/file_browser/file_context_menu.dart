import 'package:flutter/material.dart';
import '../../app/theme.dart';
import '../../core/models/file_item.dart';

class FileContextMenu extends StatelessWidget {
  final FileItem file;
  final VoidCallback onDelete;
  final VoidCallback onRename;
  final VoidCallback onOpenInEditor;
  final VoidCallback onShare;
  final VoidCallback onCopyPath;

  const FileContextMenu({
    super.key, required this.file, required this.onDelete,
    required this.onRename, required this.onOpenInEditor,
    required this.onShare, required this.onCopyPath,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            width: 36, height: 4,
            decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(file.name, style: const TextStyle(
              fontWeight: FontWeight.w600, color: AppColors.textPrimary,
            ), maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
          const Divider(height: 1),
          _item(context, Icons.edit_outlined, 'Open in Editor', onOpenInEditor, AppColors.accentBlue),
          _item(context, Icons.drive_file_rename_outline, 'Rename', onRename),
          _item(context, Icons.content_copy, 'Copy Path', onCopyPath),
          _item(context, Icons.share, 'Share', onShare),
          _item(context, Icons.info_outline, 'Get Info', () {}),
          _item(context, Icons.tag, 'Add Tag', () {}),
          const Divider(height: 1),
          _item(context, Icons.delete_outline, 'Delete', onDelete, AppColors.accentRed),
        ],
      ),
    );
  }

  Widget _item(BuildContext context, IconData icon, String label, VoidCallback action, [Color? color]) {
    return ListTile(
      leading: Icon(icon, color: color ?? AppColors.textSecondary, size: 20),
      title: Text(label, style: TextStyle(
        color: color ?? AppColors.textPrimary, fontSize: 14,
      )),
      dense: true,
      onTap: () { Navigator.pop(context); action(); },
    );
  }
}
