import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _pageCtrl = PageController();
  int _page = 0;
  bool _storageGranted = false;
  bool _notifGranted = false;
  bool _androidDataGranted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      body: SafeArea(
        child: Column(
          children: [
            // Progress dots
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (i) => Container(
                  width: i == _page ? 24 : 8,
                  height: 8,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    color: i == _page ? AppColors.accentBlue : AppColors.border,
                    borderRadius: BorderRadius.circular(4),
                  ),
                )),
              ),
            ),

            Expanded(
              child: PageView(
                controller: _pageCtrl,
                physics: const NeverScrollableScrollPhysics(),
                onPageChanged: (i) => setState(() => _page = i),
                children: [
                  _WelcomePage(onNext: _nextPage),
                  _PermissionsPage(
                    storageGranted: _storageGranted,
                    notifGranted: _notifGranted,
                    onGrantStorage: _requestStorage,
                    onGrantNotif: _requestNotif,
                    onNext: _storageGranted ? _nextPage : null,
                  ),
                  _AndroidDataPage(
                    granted: _androidDataGranted,
                    onGrant: _requestAndroidData,
                    onSkip: _nextPage,
                    onNext: _nextPage,
                  ),
                  _AISetupPage(onDone: _finish),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _nextPage() {
    if (_page < 3) {
      _pageCtrl.animateToPage(_page + 1,
          duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
    }
  }

  Future<void> _requestStorage() async {
    final result = await fileService.requestManageStorage();
    if (result == 'granted') {
      setState(() => _storageGranted = true);
    } else {
      // Check after a delay (user comes back from settings)
      await Future.delayed(const Duration(seconds: 2));
      final check = await fileService.checkManageStorage();
      setState(() => _storageGranted = check);
    }
  }

  Future<void> _requestNotif() async {
    final result = await Permission.notification.request();
    setState(() => _notifGranted = result.isGranted);
  }

  Future<void> _requestAndroidData() async {
    // Opens the real Android SAF folder picker scoped to Android/data
    try {
      final result = await fileService.requestAndroidDataAccess();
      setState(() => _androidDataGranted = result == 'granted' || result == 'not_needed');
    } catch (e) {
      setState(() => _androidDataGranted = false);
    }
  }

  void _finish() {
    context.go('/files');
  }
}

class _WelcomePage extends StatelessWidget {
  final VoidCallback onNext;
  const _WelcomePage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 100, height: 100,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.accentBlue, AppColors.accentCyan],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(
                color: AppColors.accentBlue.withOpacity(0.4),
                blurRadius: 20, offset: const Offset(0, 8),
              )],
            ),
            child: const Icon(Icons.folder_special, size: 52, color: Colors.white),
          ),
          const SizedBox(height: 36),
          const Text('PowerFiles', style: TextStyle(
            fontSize: 34, fontWeight: FontWeight.bold, color: AppColors.textPrimary,
            letterSpacing: -0.5,
          )),
          const SizedBox(height: 12),
          const Text(
            'Everything in One App',
            style: TextStyle(fontSize: 18, color: AppColors.accentCyan, fontWeight: FontWeight.w500),
          ),
          const SizedBox(height: 20),
          const Text(
            'File manager, code editor, AI assistant,\nterminal & Telegram bot — all in one.',
            style: TextStyle(fontSize: 15, color: AppColors.textSecondary, height: 1.6),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 48),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onNext,
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
              child: const Text('Get Started', style: TextStyle(fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }
}

class _PermissionsPage extends StatelessWidget {
  final bool storageGranted;
  final bool notifGranted;
  final VoidCallback onGrantStorage;
  final VoidCallback onGrantNotif;
  final VoidCallback? onNext;

  const _PermissionsPage({
    required this.storageGranted, required this.notifGranted,
    required this.onGrantStorage, required this.onGrantNotif, this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          const Text('Permissions', style: TextStyle(
            fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.textPrimary,
          )),
          const SizedBox(height: 8),
          const Text('PowerFiles needs access to work properly.',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 15)),
          const SizedBox(height: 36),

          _permTile(
            icon: Icons.storage,
            title: 'All Files Access',
            subtitle: 'Required to browse and manage all files on your device.',
            isGranted: storageGranted,
            isRequired: true,
            onGrant: onGrantStorage,
          ),
          const SizedBox(height: 14),
          _permTile(
            icon: Icons.notifications_outlined,
            title: 'Notifications',
            subtitle: 'For storage alerts and Telegram bot updates.',
            isGranted: notifGranted,
            isRequired: false,
            onGrant: onGrantNotif,
          ),

          const Spacer(),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onNext,
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
              child: Text(storageGranted ? 'Continue' : 'Grant Required Permission',
                  style: const TextStyle(fontSize: 16)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _permTile({
    required IconData icon, required String title, required String subtitle,
    required bool isGranted, required bool isRequired, required VoidCallback onGrant,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isGranted ? AppColors.accentGreen.withOpacity(0.08) : AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isGranted ? AppColors.accentGreen.withOpacity(0.4) : AppColors.border,
        ),
      ),
      child: Row(children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: (isGranted ? AppColors.accentGreen : AppColors.accentBlue).withOpacity(0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon,
              color: isGranted ? AppColors.accentGreen : AppColors.accentBlue, size: 24),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            if (isRequired) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                decoration: BoxDecoration(
                  color: AppColors.accentRed.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text('Required', style: TextStyle(
                  fontSize: 9, color: AppColors.accentRed, fontWeight: FontWeight.bold,
                )),
              ),
            ],
          ]),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4)),
        ])),
        const SizedBox(width: 10),
        isGranted
            ? const Icon(Icons.check_circle, color: AppColors.accentGreen, size: 28)
            : TextButton(onPressed: onGrant, child: const Text('Grant')),
      ]),
    );
  }
}

class _AndroidDataPage extends StatelessWidget {
  final bool granted;
  final VoidCallback onGrant;
  final VoidCallback onSkip;
  final VoidCallback onNext;

  const _AndroidDataPage({
    required this.granted, required this.onGrant,
    required this.onSkip, required this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 20),
        const Text('Android/data Access', style: TextStyle(
          fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.textPrimary,
        )),
        const SizedBox(height: 8),
        const Text('Optional: Access app data folders without root.',
            style: TextStyle(color: AppColors.textSecondary, fontSize: 15)),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.accentAmber.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.accentAmber.withOpacity(0.3)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [
              Icon(Icons.info_outline, color: AppColors.accentAmber, size: 18),
              SizedBox(width: 8),
              Text('How to grant:', style: TextStyle(
                fontWeight: FontWeight.w600, color: AppColors.accentAmber,
              )),
            ]),
            const SizedBox(height: 10),
            ...[
              '1. Tap "Grant Access" below',
              '2. Navigate to the Android folder',
              '3. Tap "Use this folder"',
              '4. Tap "Allow" in the popup',
            ].map((s) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(s, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            )),
          ]),
        ),
        const Spacer(),
        if (!granted) ...[
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onGrant,
              icon: const Icon(Icons.folder_open),
              label: const Text('Grant Android/data Access', style: TextStyle(fontSize: 15)),
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: onSkip,
              style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
              child: const Text('Skip for Now'),
            ),
          ),
        ] else ...[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.accentGreen.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.check_circle, color: AppColors.accentGreen),
              SizedBox(width: 8),
              Text('Access Granted!', style: TextStyle(color: AppColors.accentGreen, fontWeight: FontWeight.w600)),
            ]),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onNext,
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
              child: const Text('Continue', style: TextStyle(fontSize: 16)),
            ),
          ),
        ],
      ]),
    );
  }
}

class _AISetupPage extends StatelessWidget {
  final VoidCallback onDone;
  const _AISetupPage({required this.onDone});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 20),
        const Text('AI Setup', style: TextStyle(
          fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.textPrimary,
        )),
        const SizedBox(height: 8),
        const Text('Add an AI provider to unlock intelligent features.',
            style: TextStyle(color: AppColors.textSecondary, fontSize: 15)),
        const SizedBox(height: 28),

        _providerOption(context,
          icon: Icons.bolt, color: AppColors.accentGreen,
          name: 'Groq (Free & Fast)',
          desc: 'Free API key at console.groq.com\nLlama 3.3 70B — very fast',
          badge: 'RECOMMENDED',
          onTap: () => context.push('/settings/ai-providers'),
        ),
        const SizedBox(height: 12),
        _providerOption(context,
          icon: Icons.auto_awesome, color: AppColors.accentBlue,
          name: 'OpenAI (GPT-4o)',
          desc: 'Best quality. API key at platform.openai.com',
          onTap: () => context.push('/settings/ai-providers'),
        ),
        const SizedBox(height: 12),
        _providerOption(context,
          icon: Icons.psychology, color: AppColors.accentPurple,
          name: 'Anthropic Claude',
          desc: 'Excellent for code & analysis. console.anthropic.com',
          onTap: () => context.push('/settings/ai-providers'),
        ),

        const Spacer(),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () => context.push('/settings/ai-providers'),
            icon: const Icon(Icons.add),
            label: const Text('Quick Setup → Add Provider', style: TextStyle(fontSize: 15)),
            style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15)),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: TextButton(
            onPressed: onDone,
            child: const Text('Skip — Set up later'),
          ),
        ),
      ]),
    );
  }

  Widget _providerOption(BuildContext context, {
    required IconData icon, required Color color, required String name,
    required String desc, String? badge, required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              if (badge != null) ...[
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.accentGreen.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(badge, style: const TextStyle(
                    fontSize: 9, color: AppColors.accentGreen, fontWeight: FontWeight.bold,
                  )),
                ),
              ],
            ]),
            const SizedBox(height: 4),
            Text(desc, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4)),
          ])),
          const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.textDisabled),
        ]),
      ),
    );
  }
}
