import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../../app/theme.dart';

class _LocalModel {
  final String name;
  final String publisher;
  final String url;
  final int sizeMb;
  final int ramMb;
  final String bestFor;
  final int stars;
  final String quantization;
  final String filename;

  const _LocalModel({
    required this.name, required this.publisher, required this.url,
    required this.sizeMb, required this.ramMb, required this.bestFor,
    required this.stars, required this.quantization, required this.filename,
  });
}

const _catalogModels = [
  _LocalModel(name: 'Llama 3.2 1B', publisher: 'Meta', stars: 2, ramMb: 2048,
    sizeMb: 700, bestFor: 'Quick answers', quantization: 'Q4_K_M',
    filename: 'llama-3.2-1b-q4_k_m.gguf',
    url: 'https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf'),
  _LocalModel(name: 'Llama 3.2 3B', publisher: 'Meta', stars: 3, ramMb: 4096,
    sizeMb: 1800, bestFor: 'General chat', quantization: 'Q4_K_M',
    filename: 'llama-3.2-3b-q4_k_m.gguf',
    url: 'https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf'),
  _LocalModel(name: 'Phi-3.5 Mini', publisher: 'Microsoft', stars: 3, ramMb: 4096,
    sizeMb: 2200, bestFor: 'Reasoning', quantization: 'Q4_K_M',
    filename: 'phi-3.5-mini-q4.gguf',
    url: 'https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF/resolve/main/Phi-3.5-mini-instruct-Q4_K_M.gguf'),
  _LocalModel(name: 'Gemma 2 2B', publisher: 'Google', stars: 3, ramMb: 3072,
    sizeMb: 1600, bestFor: 'Google quality', quantization: 'Q4_K_M',
    filename: 'gemma-2-2b-q4.gguf',
    url: 'https://huggingface.co/bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf'),
  _LocalModel(name: 'Qwen2.5 Coder 1.5B', publisher: 'Alibaba', stars: 3, ramMb: 2048,
    sizeMb: 1000, bestFor: 'Code writing', quantization: 'Q4_K_M',
    filename: 'qwen2.5-coder-1.5b-q4.gguf',
    url: 'https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf'),
  _LocalModel(name: 'DeepSeek-R1 1.5B', publisher: 'DeepSeek', stars: 3, ramMb: 2048,
    sizeMb: 1100, bestFor: 'Reasoning', quantization: 'Q4_K_M',
    filename: 'deepseek-r1-1.5b-q4.gguf',
    url: 'https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF/resolve/main/DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf'),
  _LocalModel(name: 'Mistral 7B', publisher: 'Mistral AI', stars: 4, ramMb: 6144,
    sizeMb: 4100, bestFor: 'Best quality', quantization: 'Q4_K_M',
    filename: 'mistral-7b-q4.gguf',
    url: 'https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf'),
  _LocalModel(name: 'CodeLlama 7B', publisher: 'Meta', stars: 4, ramMb: 6144,
    sizeMb: 4000, bestFor: 'Code specialist', quantization: 'Q4_K_M',
    filename: 'codellama-7b-q4.gguf',
    url: 'https://huggingface.co/TheBloke/CodeLlama-7B-Instruct-GGUF/resolve/main/codellama-7b-instruct.Q4_K_M.gguf'),
];

class LocalModelsScreen extends StatefulWidget {
  const LocalModelsScreen({super.key});
  @override
  State<LocalModelsScreen> createState() => _LocalModelsScreenState();
}

class _LocalModelsScreenState extends State<LocalModelsScreen> {
  final Map<String, double> _downloadProgress = {};
  final Map<String, bool> _isDownloading = {};
  Set<String> _downloaded = {};
  String _modelsDir = '';
  int _deviceRam = 4096; // default 4GB

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final dir = await getApplicationDocumentsDirectory();
    final modelsDir = Directory('${dir.path}/models');
    if (!modelsDir.existsSync()) modelsDir.createSync();
    final downloaded = modelsDir.listSync()
        .whereType<File>()
        .map((f) => f.uri.pathSegments.last)
        .toSet();
    setState(() {
      _modelsDir = modelsDir.path;
      _downloaded = downloaded;
    });
  }

  bool _canRun(_LocalModel m) => m.ramMb <= _deviceRam;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: const Text('Local Models'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: Text(
              'RAM: ${(_deviceRam / 1024).toStringAsFixed(0)} GB',
              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
            )),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _catalogModels.length,
              itemBuilder: (_, i) => _ModelCard(
                model: _catalogModels[i],
                isDownloaded: _downloaded.contains(_catalogModels[i].filename),
                isDownloading: _isDownloading[_catalogModels[i].filename] == true,
                progress: _downloadProgress[_catalogModels[i].filename] ?? 0,
                canRun: _canRun(_catalogModels[i]),
                modelsDir: _modelsDir,
                onDownload: () => _download(_catalogModels[i]),
                onDelete: () => _deleteModel(_catalogModels[i]),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.accentBlue.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.accentBlue.withOpacity(0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [
          Icon(Icons.memory, color: AppColors.accentBlue, size: 18),
          SizedBox(width: 8),
          Text('On-Device AI Models', style: TextStyle(
            fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.textPrimary,
          )),
        ]),
        const SizedBox(height: 6),
        const Text(
          'Run AI models locally without internet. Models stored in app private directory.',
          style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.4),
        ),
        const SizedBox(height: 10),
        Row(children: [
          const Text('Your device RAM: ', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          Expanded(child: DropdownButton<int>(
            value: _deviceRam,
            isDense: true,
            dropdownColor: AppColors.bgTertiary,
            style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
            underline: const SizedBox.shrink(),
            items: [2048, 3072, 4096, 6144, 8192, 12288, 16384].map((ram) =>
              DropdownMenuItem(value: ram, child: Text('${ram ~/ 1024} GB'))).toList(),
            onChanged: (v) => setState(() => _deviceRam = v ?? 4096),
          )),
        ]),
      ]),
    );
  }

  Future<void> _download(_LocalModel model) async {
    setState(() {
      _isDownloading[model.filename] = true;
      _downloadProgress[model.filename] = 0;
    });

    try {
      final destFile = File('$_modelsDir/${model.filename}');
      final client = http.Client();
      final req = http.Request('GET', Uri.parse(model.url));
      final response = await client.send(req);
      final totalBytes = response.contentLength ?? (model.sizeMb * 1024 * 1024);

      final sink = destFile.openWrite();
      int received = 0;

      await for (final chunk in response.stream) {
        if (_isDownloading[model.filename] != true) {
          sink.close();
          if (destFile.existsSync()) destFile.deleteSync();
          return;
        }
        sink.add(chunk);
        received += chunk.length;
        setState(() => _downloadProgress[model.filename] = received / totalBytes);
      }
      await sink.close();
      client.close();

      setState(() {
        _downloaded.add(model.filename);
        _isDownloading.remove(model.filename);
        _downloadProgress.remove(model.filename);
      });

      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${model.name} downloaded!')),
      );
    } catch (e) {
      setState(() {
        _isDownloading.remove(model.filename);
        _downloadProgress.remove(model.filename);
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Download failed: $e')),
      );
    }
  }

  void _deleteModel(_LocalModel model) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Model'),
        content: Text('Delete ${model.name}? (${model.sizeMb} MB will be freed)'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentRed),
            onPressed: () {
              Navigator.pop(context);
              final f = File('$_modelsDir/${model.filename}');
              if (f.existsSync()) f.deleteSync();
              setState(() => _downloaded.remove(model.filename));
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

class _ModelCard extends StatelessWidget {
  final _LocalModel model;
  final bool isDownloaded;
  final bool isDownloading;
  final double progress;
  final bool canRun;
  final String modelsDir;
  final VoidCallback onDownload;
  final VoidCallback onDelete;

  const _ModelCard({
    required this.model, required this.isDownloaded, required this.isDownloading,
    required this.progress, required this.canRun, required this.modelsDir,
    required this.onDownload, required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDownloaded ? AppColors.accentGreen.withOpacity(0.3) : AppColors.border,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(model.name, style: const TextStyle(
                fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.textPrimary,
              )),
              const SizedBox(width: 8),
              _starRating(model.stars),
            ]),
            const SizedBox(height: 2),
            Text(model.publisher, style: const TextStyle(
              fontSize: 11, color: AppColors.textSecondary,
            )),
          ])),
          if (isDownloaded)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: AppColors.accentGreen.withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text('✓ Ready', style: TextStyle(
                fontSize: 11, color: AppColors.accentGreen, fontWeight: FontWeight.w600,
              )),
            ),
        ]),

        const SizedBox(height: 10),

        // Info chips
        Wrap(spacing: 6, runSpacing: 6, children: [
          _chip('${model.sizeMb >= 1024 ? '${(model.sizeMb / 1024).toStringAsFixed(1)} GB' : '${model.sizeMb} MB'}', Icons.download, AppColors.textSecondary),
          _chip('${(model.ramMb / 1024).toStringAsFixed(0)} GB RAM', Icons.memory,
              canRun ? AppColors.accentGreen : AppColors.accentRed),
          _chip(model.bestFor, Icons.star_outline, AppColors.accentAmber),
          _chip(model.quantization, Icons.compress, AppColors.accentCyan),
        ]),

        if (!canRun)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              '⚠️ Insufficient RAM — select higher RAM above',
              style: const TextStyle(fontSize: 11, color: AppColors.accentAmber),
            ),
          ),

        const SizedBox(height: 12),

        if (isDownloading) ...[
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Downloading... ${(progress * 100).toInt()}%',
                style: const TextStyle(fontSize: 12, color: AppColors.accentBlue)),
            Text(_fmtBytes((progress * model.sizeMb * 1024 * 1024).toInt()) + ' / ' +
                _fmtBytes(model.sizeMb * 1024 * 1024),
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ]),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: LinearProgressIndicator(
              value: progress, minHeight: 6,
              backgroundColor: AppColors.border, color: AppColors.accentBlue,
            ),
          ),
        ] else Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          if (isDownloaded) ...[
            OutlinedButton.icon(
              onPressed: onDelete,
              icon: const Icon(Icons.delete_outline, size: 16, color: AppColors.accentRed),
              label: const Text('Delete', style: TextStyle(color: AppColors.accentRed)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.accentRed),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Set as active in AI providers → Local')),
              ),
              icon: const Icon(Icons.play_arrow, size: 16),
              label: const Text('Use'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.accentGreen,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              ),
            ),
          ] else ElevatedButton.icon(
            onPressed: canRun ? onDownload : null,
            icon: const Icon(Icons.download, size: 16),
            label: const Text('Download'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
          ),
        ]),
      ]),
    );
  }

  Widget _starRating(int stars) {
    return Row(children: List.generate(5, (i) => Icon(
      i < stars ? Icons.star : Icons.star_border,
      size: 12, color: AppColors.accentAmber,
    )));
  }

  Widget _chip(String label, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 11, color: color),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(fontSize: 11, color: color)),
      ]),
    );
  }

  String _fmtBytes(int bytes) {
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}
