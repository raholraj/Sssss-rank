import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../app/theme.dart';
import '../../core/services/ai_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  List<AIProvider> _fallbackProviders = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    aiService.init().then((_) {
      if (mounted) setState(() {
        _fallbackProviders = aiService.providers
            .where((p) => ['google', 'groq', 'openrouter'].contains(p.id))
            .toList();
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        children: [
          // ── AI Fallback Status Card ──
          _buildFallbackCard(),

          _header('Tools'),
          _tile(context, Icons.terminal, 'Terminal', 'Bash shell', () => context.push('/terminal')),
          _tile(context, Icons.folder_special, 'Projects', 'Manage project workspaces', () => context.push('/projects')),
          _tile(context, Icons.telegram, 'Telegram Bot', 'Remote control via Telegram', () => context.push('/telegram')),

          _header('AI & Intelligence'),
          _tile(context, Icons.smart_toy_outlined, 'AI Providers', 'Configure API keys & models', () => context.push('/settings/ai-providers')),
          _tile(context, Icons.memory, 'Local Models', 'Download & run models on-device', () => context.push('/settings/local-models')),

          _header('File Manager'),
          _settingsTile(context),

          _header('About'),
          _tile(context, Icons.info_outline, 'About PowerFiles', 'Version 1.0.0', () {}),
          _tile(context, Icons.security, 'Permissions', 'Check app permissions', () => _checkPerms(context)),
        ],
      ),
    );
  }

  Widget _buildFallbackCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 16, 12, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.accentBlue.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.auto_awesome, color: AppColors.accentBlue, size: 16),
          const SizedBox(width: 8),
          const Text('Auto AI Fallback', style: TextStyle(
            fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.textPrimary,
          )),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: AppColors.accentGreen.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text('ACTIVE', style: TextStyle(
              fontSize: 10, color: AppColors.accentGreen, fontWeight: FontWeight.w700,
            )),
          ),
        ]),
        const SizedBox(height: 10),
        const Text(
          'If one provider fails, the next one is tried automatically.',
          style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 10),
        _loading
            ? const Center(child: SizedBox(height: 20, width: 20,
                child: CircularProgressIndicator(strokeWidth: 2)))
            : Row(children: [
                for (int i = 0; i < _fallbackProviders.length; i++) ...[
                  _fallbackBadge(_fallbackProviders[i], i + 1),
                  if (i < _fallbackProviders.length - 1)
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4),
                      child: Icon(Icons.arrow_forward, size: 12, color: AppColors.textDisabled),
                    ),
                ],
              ]),
      ]),
    );
  }

  Widget _fallbackBadge(AIProvider p, int priority) {
    const colors = [AppColors.accentGreen, AppColors.accentAmber, AppColors.accentCyan];
    final color = colors[(priority - 1).clamp(0, 2)];
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(children: [
          Text('$priority', style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(
            p.name.split(' ').first,
            style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600),
            textAlign: TextAlign.center, overflow: TextOverflow.ellipsis,
          ),
        ]),
      ),
    );
  }

  Widget _header(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
    child: Text(title.toUpperCase(), style: const TextStyle(
      fontSize: 11, color: AppColors.textSecondary,
      letterSpacing: 1.2, fontWeight: FontWeight.w600,
    )),
  );

  Widget _tile(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          color: AppColors.accentBlue.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, size: 18, color: AppColors.accentBlue),
      ),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      trailing: const Icon(Icons.chevron_right, size: 18, color: AppColors.textDisabled),
      onTap: onTap,
    );
  }

  Widget _settingsTile(BuildContext context) {
    return Column(children: [
      _tile(context, Icons.visibility_outlined, 'Show Hidden Files', 'Toggle dotfiles visibility', () {}),
      _tile(context, Icons.sort, 'Sort Preference', 'Name / Size / Date', () {}),
      _tile(context, Icons.delete_outline, 'Recycle Bin', 'View or empty recycle bin', () {}),
    ]);
  }

  void _checkPerms(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Permissions'),
        content: const Text('All Files Access: Required\nNotifications: Recommended\nInternet: Required'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }
}
