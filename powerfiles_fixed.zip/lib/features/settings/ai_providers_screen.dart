import 'package:flutter/material.dart';
import '../../app/theme.dart';
import '../../core/services/ai_service.dart';

class AiProvidersScreen extends StatefulWidget {
  const AiProvidersScreen({super.key});
  @override
  State<AiProvidersScreen> createState() => _AiProvidersScreenState();
}

class _AiProvidersScreenState extends State<AiProvidersScreen> {
  List<AIProvider> _providers = [];

  @override
  void initState() {
    super.initState();
    aiService.init().then((_) => setState(() => _providers = aiService.providers.toList()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: const Text('AI Providers'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showProviderForm(context, null),
          ),
        ],
      ),
      body: _providers.isEmpty
          ? _buildEmpty()
          : ListView.builder(
              itemCount: _providers.length,
              itemBuilder: (_, i) => _ProviderCard(
                provider: _providers[i],
                onEdit: () => _showProviderForm(context, _providers[i]),
                onDelete: () => _deleteProvider(_providers[i].id),
                onSetActive: () => _setActive(_providers[i].id),
                isActive: aiService.activeProvider?.id == _providers[i].id,
              ),
            ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.cloud_off, size: 64, color: AppColors.textDisabled),
        const SizedBox(height: 16),
        const Text('No providers configured', style: TextStyle(
          fontSize: 18, color: AppColors.textPrimary, fontWeight: FontWeight.w600,
        )),
        const SizedBox(height: 8),
        const Text('Add a provider to use AI features',
            style: TextStyle(color: AppColors.textSecondary)),
        const SizedBox(height: 24),
        ElevatedButton.icon(
          onPressed: () => _showProviderForm(context, null),
          icon: const Icon(Icons.add), label: const Text('Add Provider'),
        ),
      ]),
    );
  }

  void _showProviderForm(BuildContext context, AIProvider? existing) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _ProviderFormSheet(
        existing: existing,
        onSave: (p) async {
          await aiService.saveProvider(p);
          if (mounted) setState(() => _providers = aiService.providers.toList());
        },
      ),
    );
  }

  void _deleteProvider(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Remove Provider'),
        content: const Text('Remove this AI provider? Your API key will be deleted.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentRed),
            onPressed: () async {
              Navigator.pop(context);
              await aiService.removeProvider(id);
              if (mounted) setState(() => _providers = aiService.providers.toList());
            },
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _setActive(String id) async {
    await aiService.setActiveProvider(id);
    if (mounted) setState(() {});
  }
}

class _ProviderCard extends StatelessWidget {
  final AIProvider provider;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onSetActive;
  final bool isActive;

  const _ProviderCard({
    required this.provider, required this.onEdit, required this.onDelete,
    required this.onSetActive, required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    final hasKey = provider.apiKey.isNotEmpty;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: isActive ? AppColors.accentBlue.withOpacity(0.08) : AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isActive ? AppColors.accentBlue.withOpacity(0.4) : AppColors.border),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ListTile(
          leading: Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: AppColors.accentBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(_providerIcon(provider.type), color: AppColors.accentBlue, size: 22),
          ),
          title: Row(children: [
            Expanded(child: Text(provider.name, style: const TextStyle(
              fontWeight: FontWeight.w600, fontSize: 14,
            ))),
            if (isActive)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.accentBlue.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('ACTIVE', style: TextStyle(
                  fontSize: 9, color: AppColors.accentBlue, fontWeight: FontWeight.bold,
                )),
              ),
          ]),
          subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 2),
            Text(provider.selectedModel, style: const TextStyle(
              fontSize: 12, fontFamily: 'monospace', color: AppColors.textSecondary,
            )),
            const SizedBox(height: 2),
            Row(children: [
              Icon(
                hasKey ? Icons.check_circle : Icons.warning_amber,
                size: 12,
                color: hasKey ? AppColors.accentGreen : AppColors.accentAmber,
              ),
              const SizedBox(width: 4),
              Text(
                hasKey ? 'API key set' : 'No API key',
                style: TextStyle(
                  fontSize: 11,
                  color: hasKey ? AppColors.accentGreen : AppColors.accentAmber,
                ),
              ),
            ]),
          ]),
          trailing: PopupMenuButton(
            icon: const Icon(Icons.more_vert, size: 18),
            itemBuilder: (_) => [
              if (!isActive) PopupMenuItem(value: 'active', child: const Text('Set as Active')),
              const PopupMenuItem(value: 'edit', child: Text('Edit')),
              const PopupMenuItem(value: 'delete', child: Text('Remove',
                  style: TextStyle(color: AppColors.accentRed))),
            ],
            onSelected: (v) {
              if (v == 'edit') onEdit();
              if (v == 'delete') onDelete();
              if (v == 'active') onSetActive();
            },
          ),
        ),
      ]),
    );
  }

  IconData _providerIcon(AIProviderType t) {
    switch (t) {
      case AIProviderType.openai: return Icons.auto_awesome;
      case AIProviderType.anthropic: return Icons.psychology;
      case AIProviderType.google: return Icons.colorize;
      case AIProviderType.groq: return Icons.bolt;
      case AIProviderType.ollama:
      case AIProviderType.lmstudio:
      case AIProviderType.local: return Icons.computer;
      default: return Icons.cloud;
    }
  }
}

class _ProviderFormSheet extends StatefulWidget {
  final AIProvider? existing;
  final Function(AIProvider) onSave;
  const _ProviderFormSheet({this.existing, required this.onSave});

  @override
  State<_ProviderFormSheet> createState() => _ProviderFormSheetState();
}

class _ProviderFormSheetState extends State<_ProviderFormSheet> {
  AIProvider? _selected;
  final _keyCtrl = TextEditingController();
  String _selectedModel = '';
  bool _obscureKey = true;
  bool _isFetchingModels = false;
  List<String> _fetchedModels = [];

  @override
  void initState() {
    super.initState();
    if (widget.existing != null) {
      _selected = widget.existing;
      _keyCtrl.text = widget.existing!.apiKey;
      _selectedModel = widget.existing!.selectedModel;
    }
  }

  @override
  void dispose() {
    _keyCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(widget.existing != null ? 'Edit Provider' : 'Add AI Provider',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
            ]),
            const SizedBox(height: 16),

            // Provider selector
            if (widget.existing == null) ...[
              const Text('Provider', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
              const SizedBox(height: 8),
              SizedBox(
                height: 50,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: ProviderPresets.all.map((p) => GestureDetector(
                    onTap: () => setState(() {
                      _selected = p;
                      _selectedModel = p.selectedModel;
                    }),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: _selected?.id == p.id
                            ? AppColors.accentBlue.withOpacity(0.15) : AppColors.bgTertiary,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _selected?.id == p.id ? AppColors.accentBlue : AppColors.border,
                        ),
                      ),
                      child: Text(p.name, style: TextStyle(
                        fontSize: 12,
                        color: _selected?.id == p.id ? AppColors.accentBlue : AppColors.textSecondary,
                        fontWeight: _selected?.id == p.id ? FontWeight.w600 : FontWeight.normal,
                      )),
                    ),
                  )).toList(),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // API Key
            if (_selected != null) ...[
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('API Key', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                if (_selected!.type == AIProviderType.ollama ||
                    _selected!.type == AIProviderType.lmstudio)
                  const Text('(not required)', style: TextStyle(
                    fontSize: 11, color: AppColors.textDisabled,
                  )),
              ]),
              const SizedBox(height: 8),
              TextField(
                controller: _keyCtrl,
                obscureText: _obscureKey,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'sk-...',
                  suffixIcon: IconButton(
                    icon: Icon(_obscureKey ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _obscureKey = !_obscureKey),
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Model selector
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('Model', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                TextButton.icon(
                  onPressed: _isFetchingModels ? null : _fetchModels,
                  icon: _isFetchingModels
                      ? const SizedBox(width: 14, height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.refresh, size: 14),
                  label: const Text('Fetch', style: TextStyle(fontSize: 12)),
                ),
              ]),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _selectedModel.isNotEmpty ? _selectedModel : null,
                dropdownColor: AppColors.bgTertiary,
                decoration: const InputDecoration(hintText: 'Select model'),
                items: [
                  ..._selected!.models,
                  ..._fetchedModels.where((m) => !_selected!.models.contains(m)),
                ].map((m) => DropdownMenuItem(value: m, child: Text(m,
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 13)))).toList(),
                onChanged: (v) => setState(() => _selectedModel = v ?? ''),
              ),
              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _save,
                  child: const Text('Save Provider'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _fetchModels() async {
    if (_selected == null || _keyCtrl.text.isEmpty) return;
    setState(() => _isFetchingModels = true);
    final p = _selected!.copyWith(apiKey: _keyCtrl.text);
    final models = await aiService.fetchModels(p);
    setState(() {
      _fetchedModels = models;
      _isFetchingModels = false;
      if (models.isNotEmpty && _selectedModel.isEmpty) _selectedModel = models.first;
    });
  }

  void _save() {
    if (_selected == null) return;
    final saved = _selected!.copyWith(
      apiKey: _keyCtrl.text.trim(),
      selectedModel: _selectedModel,
    );
    widget.onSave(saved);
    Navigator.pop(context);
  }
}
