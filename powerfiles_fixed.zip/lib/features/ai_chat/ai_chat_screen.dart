import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../app/theme.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/file_service.dart';

final _providerProvider = StateProvider<AIProvider?>((ref) => null);
final _messagesProvider = StateNotifierProvider<_MsgNotifier, List<ChatMessage>>(
    (_) => _MsgNotifier());

class _MsgNotifier extends StateNotifier<List<ChatMessage>> {
  _MsgNotifier() : super([]);
  void add(ChatMessage m) => state = [...state, m];
  void updateLast(String content, {bool streaming = true}) {
    if (state.isEmpty) return;
    final updated = state.last.copyWith(content: content, isStreaming: streaming);
    state = [...state.sublist(0, state.length - 1), updated];
  }
  void clear() => state = [];
}

class AiChatScreen extends ConsumerStatefulWidget {
  const AiChatScreen({super.key});
  @override
  ConsumerState<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends ConsumerState<AiChatScreen> {
  final _textCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool _isGenerating = false;
  String? _attachedFile;
  int _tokenEstimate = 0;

  @override
  void initState() {
    super.initState();
    aiService.init().then((_) {
      if (mounted) {
        // Default to first provider that has a key (Gemini if pre-configured)
        final withKey = aiService.providers.firstWhere(
          (p) => p.apiKey.isNotEmpty,
          orElse: () => aiService.providers.first,
        );
        ref.read(_providerProvider.notifier).state =
            aiService.activeProvider ?? withKey;
      }
    });
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = ref.watch(_providerProvider);
    final messages = ref.watch(_messagesProvider);

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: _buildAppBar(provider, messages),
      body: Column(
        children: [
          Expanded(
            child: messages.isEmpty
                ? _buildWelcome(provider)
                : _buildMessageList(messages),
          ),
          if (_attachedFile != null) _buildAttachmentBanner(),
          _buildInputBar(provider),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(AIProvider? provider, List<ChatMessage> messages) {
    final tokenColor = _tokenEstimate > 80000
        ? AppColors.accentRed
        : _tokenEstimate > 40000
            ? AppColors.accentAmber
            : AppColors.accentGreen;

    return AppBar(
      title: Row(children: [
        const Icon(Icons.smart_toy, color: AppColors.accentBlue, size: 20),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('AI Assistant', style: TextStyle(fontSize: 15)),
              if (provider != null)
                Text(provider.name, style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.normal,
                )),
            ],
          ),
        ),
      ]),
      actions: [
        if (messages.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: tokenColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: tokenColor.withOpacity(0.4)),
                ),
                child: Text(
                  '~${(_tokenEstimate / 1000).toStringAsFixed(0)}K ctx',
                  style: TextStyle(fontSize: 10, color: tokenColor, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ),
        IconButton(
          icon: const Icon(Icons.swap_horiz),
          tooltip: 'Change provider',
          onPressed: () => _showProviderPicker(context),
        ),
        if (messages.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.delete_outline, color: AppColors.accentRed),
            onPressed: () {
              ref.read(_messagesProvider.notifier).clear();
              setState(() => _tokenEstimate = 0);
            },
          ),
        IconButton(
          icon: const Icon(Icons.settings_outlined),
          onPressed: () => context.push('/settings/ai-providers'),
        ),
      ],
    );
  }

  Widget _buildWelcome(AIProvider? provider) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.accentBlue.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.accentBlue.withOpacity(0.3)),
              ),
              child: const Icon(Icons.smart_toy, size: 48, color: AppColors.accentBlue),
            ),
            const SizedBox(height: 20),
            Text(
              provider != null ? 'Ask me anything!' : 'No AI provider configured',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600,
                  color: AppColors.textPrimary),
            ),
            const SizedBox(height: 8),
            Text(
              provider != null
                  ? 'I can help manage files, write code,\nanalyze storage, and more.'
                  : 'Add a provider in Settings → AI Providers',
              style: const TextStyle(fontSize: 14, color: AppColors.textSecondary, height: 1.5),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            if (provider == null)
              ElevatedButton.icon(
                onPressed: () => context.push('/settings/ai-providers'),
                icon: const Icon(Icons.add),
                label: const Text('Add AI Provider'),
              ),
            if (provider != null) ...[
              const Text('Quick prompts:', style: TextStyle(
                fontSize: 12, color: AppColors.textSecondary, letterSpacing: 0.3)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                _quickChip('Find duplicate files', Icons.content_copy),
                _quickChip('Clean junk files', Icons.delete_sweep),
                _quickChip('Show storage breakdown', Icons.pie_chart),
                _quickChip('Write a Flutter widget', Icons.code),
                _quickChip('Organize my Downloads', Icons.folder_special),
              ]),
            ],
          ],
        ),
      ),
    );
  }

  Widget _quickChip(String text, IconData icon) {
    return ActionChip(
      avatar: Icon(icon, size: 14, color: AppColors.accentCyan),
      label: Text(text, style: const TextStyle(fontSize: 12)),
      onPressed: () {
        _textCtrl.text = text;
        _send();
      },
    );
  }

  Widget _buildMessageList(List<ChatMessage> messages) {
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      itemCount: messages.length,
      itemBuilder: (_, i) => _MessageBubble(message: messages[i]),
    );
  }

  Widget _buildAttachmentBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.accentBlue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.accentBlue.withOpacity(0.3)),
      ),
      child: Row(children: [
        const Icon(Icons.attach_file, color: AppColors.accentBlue, size: 16),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            _attachedFile!.split('/').last,
            style: const TextStyle(fontSize: 12, color: AppColors.textPrimary),
            maxLines: 1, overflow: TextOverflow.ellipsis,
          ),
        ),
        GestureDetector(
          onTap: () => setState(() => _attachedFile = null),
          child: const Icon(Icons.close, size: 16, color: AppColors.textSecondary),
        ),
      ]),
    );
  }

  Widget _buildInputBar(AIProvider? provider) {
    return Container(
      padding: EdgeInsets.only(
        left: 12, right: 12, top: 10,
        bottom: MediaQuery.of(context).viewInsets.bottom + 10,
      ),
      decoration: const BoxDecoration(
        color: AppColors.bgSecondary,
        border: Border(top: BorderSide(color: AppColors.border)),
      ),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.attach_file, size: 20),
          color: AppColors.textSecondary,
          onPressed: _attachFile,
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: TextField(
            controller: _textCtrl,
            maxLines: 4,
            minLines: 1,
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.sentences,
            style: const TextStyle(fontSize: 14, color: AppColors.textPrimary),
            decoration: InputDecoration(
              hintText: provider == null
                  ? 'Set up a provider first...'
                  : 'Ask anything...',
              hintStyle: const TextStyle(color: AppColors.textDisabled, fontSize: 14),
              filled: true,
              fillColor: AppColors.bgTertiary,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: const BorderSide(color: AppColors.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: const BorderSide(color: AppColors.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(20),
                borderSide: const BorderSide(color: AppColors.accentBlue),
              ),
            ),
            onSubmitted: (_) => _send(),
          ),
        ),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: _isGenerating ? _stop : (provider != null ? _send : null),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: _isGenerating
                  ? AppColors.accentRed
                  : provider == null
                      ? AppColors.textDisabled
                      : AppColors.accentBlue,
              shape: BoxShape.circle,
            ),
            child: Icon(
              _isGenerating ? Icons.stop : Icons.arrow_upward,
              color: Colors.white, size: 20,
            ),
          ),
        ),
      ]),
    );
  }

  bool _stopped = false;

  Future<void> _send() async {
    final text = _textCtrl.text.trim();
    if (text.isEmpty && _attachedFile == null) return;

    // Ensure service is initialised (has the 3 fallback providers)
    await aiService.init();

    String content = text;
    if (_attachedFile != null) {
      try {
        final fileContent = await fileService.readFile(_attachedFile!);
        final fileName = _attachedFile!.split('/').last;
        content = '$text\n\n[File: $fileName]\n```\n${fileContent.substring(0, fileContent.length.clamp(0, 8000))}\n```';
      } catch (_) {}
    }

    final userMsg = ChatMessage(role: 'user', content: content, timestamp: DateTime.now());
    ref.read(_messagesProvider.notifier).add(userMsg);
    _textCtrl.clear();
    setState(() { _attachedFile = null; _isGenerating = true; _stopped = false; });
    _scrollToBottom();

    // Add empty streaming assistant message
    ref.read(_messagesProvider.notifier).add(
      ChatMessage(role: 'assistant', content: '', timestamp: DateTime.now(), isStreaming: true),
    );

    final buffer = StringBuffer();
    String? switchedTo;
    try {
      final msgs = ref.read(_messagesProvider)
          .where((m) => m.role != 'assistant' || !m.isStreaming)
          .toList();

      // 🔄 Use fallback chain: Gemini → Groq → OpenRouter
      await for (final chunk in aiService.streamChatWithFallback(
        msgs,
        onProviderSwitch: (id, name) {
          // Show a subtle banner the first time we switch away from primary
          if (switchedTo == null && id != 'google') {
            switchedTo = name;
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('⚡ Switched to $name'),
                duration: const Duration(seconds: 2),
                backgroundColor: AppColors.bgTertiary,
                behavior: SnackBarBehavior.floating,
              ));
            }
          }
        },
      )) {
        if (_stopped) break;
        buffer.write(chunk);
        ref.read(_messagesProvider.notifier).updateLast(buffer.toString());
        _scrollToBottom();
      }
    } catch (e) {
      ref.read(_messagesProvider.notifier)
          .updateLast('❌ Error: $e', streaming: false);
    }

    ref.read(_messagesProvider.notifier).updateLast(buffer.toString(), streaming: false);
    // Update provider label in app bar after fallback
    if (mounted) {
      final lastProvider = aiService.providers.firstWhere(
        (p) => p.id == (aiService.lastUsedFallbackId ?? aiService.activeProvider?.id ?? ''),
        orElse: () => aiService.providers.first,
      );
      ref.read(_providerProvider.notifier).state = lastProvider;
    }
    setState(() { _isGenerating = false; });
    _updateTokenCount();
  }

  void _stop() => setState(() { _stopped = true; _isGenerating = false; });

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _updateTokenCount() {
    final messages = ref.read(_messagesProvider);
    final totalChars = messages.fold<int>(0, (sum, m) => sum + m.content.length);
    setState(() => _tokenEstimate = (totalChars / 4).round());
  }

  Future<void> _attachFile() async {
    // Use system file picker
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Browse files from the Files tab and use "Attach to AI"')),
    );
  }

  void _showProviderPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => _ProviderPickerSheet(
        providers: aiService.providers,
        current: ref.read(_providerProvider),
        onSelect: (p) {
          ref.read(_providerProvider.notifier).state = p;
          aiService.setActiveProvider(p.id);
        },
      ),
    );
  }

  void _showNoKeyDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('API Key Required'),
        content: const Text('This provider needs an API key. Add it in Settings → AI Providers.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () { Navigator.pop(context); context.push('/settings/ai-providers'); },
            child: const Text('Go to Settings'),
          ),
        ],
      ),
    );
  }
}

// ── Message Bubble ──
class _MessageBubble extends StatelessWidget {
  final ChatMessage message;
  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == 'user';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isUser) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: AppColors.accentBlue.withOpacity(0.15),
              child: const Icon(Icons.smart_toy, size: 16, color: AppColors.accentBlue),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: isUser ? AppColors.accentBlue : AppColors.bgSecondary,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isUser ? 16 : 4),
                      bottomRight: Radius.circular(isUser ? 4 : 16),
                    ),
                    border: isUser ? null : Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildContent(message.content, isUser),
                      if (message.isStreaming)
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: _BlinkingCursor(),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _formatTime(message.timestamp),
                  style: const TextStyle(fontSize: 10, color: AppColors.textDisabled),
                ),
              ],
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            CircleAvatar(
              radius: 14,
              backgroundColor: AppColors.accentBlue.withOpacity(0.2),
              child: const Icon(Icons.person, size: 16, color: AppColors.accentBlue),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildContent(String text, bool isUser) {
    // Simple markdown-lite: handle code blocks
    final parts = text.split('```');
    if (parts.length < 2) {
      return SelectableText(
        text,
        style: TextStyle(
          fontSize: 14, color: isUser ? Colors.white : AppColors.textPrimary, height: 1.5,
        ),
      );
    }

    final widgets = <Widget>[];
    for (int i = 0; i < parts.length; i++) {
      if (i.isEven) {
        if (parts[i].trim().isNotEmpty) {
          widgets.add(SelectableText(
            parts[i],
            style: TextStyle(
              fontSize: 14, color: isUser ? Colors.white : AppColors.textPrimary, height: 1.5,
            ),
          ));
        }
      } else {
        final lines = parts[i].split('\n');
        final lang = lines.first.trim();
        final code = lines.skip(1).join('\n');
        widgets.add(_CodeBlock(code: code, lang: lang));
      }
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: widgets);
  }

  String _formatTime(DateTime dt) {
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}

class _CodeBlock extends StatelessWidget {
  final String code;
  final String lang;
  const _CodeBlock({required this.code, required this.lang});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.bgPrimary,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (lang.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: AppColors.border)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(lang, style: const TextStyle(
                    fontSize: 11, color: AppColors.accentCyan, fontFamily: 'monospace',
                  )),
                  GestureDetector(
                    onTap: () => Clipboard.setData(ClipboardData(text: code)),
                    child: const Icon(Icons.copy, size: 14, color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(12),
            child: SelectableText(
              code,
              style: const TextStyle(
                fontFamily: 'monospace', fontSize: 12,
                color: AppColors.codeText, height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BlinkingCursor extends StatefulWidget {
  @override
  State<_BlinkingCursor> createState() => _BlinkingCursorState();
}

class _BlinkingCursorState extends State<_BlinkingCursor>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(duration: const Duration(milliseconds: 600), vsync: this)
      ..repeat(reverse: true);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _ctrl,
    child: Container(width: 8, height: 14,
        decoration: BoxDecoration(color: AppColors.accentBlue, borderRadius: BorderRadius.circular(1))),
  );
}

// ── Provider picker ──
class _ProviderPickerSheet extends StatelessWidget {
  final List<AIProvider> providers;
  final AIProvider? current;
  final ValueChanged<AIProvider> onSelect;

  const _ProviderPickerSheet({
    required this.providers, required this.current, required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text('Select AI Provider', style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w600,
            )),
          ),
          const Divider(),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: providers.length,
              itemBuilder: (_, i) {
                final p = providers[i];
                final isActive = p.id == current?.id;
                return ListTile(
                  leading: Icon(
                    _provIcon(p.type),
                    color: isActive ? AppColors.accentBlue : AppColors.textSecondary,
                  ),
                  title: Text(p.name, style: TextStyle(
                    color: isActive ? AppColors.accentBlue : AppColors.textPrimary,
                    fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                  )),
                  subtitle: p.apiKey.isEmpty
                      ? const Text('No API key', style: TextStyle(color: AppColors.accentRed, fontSize: 11))
                      : Text(p.selectedModel, style: const TextStyle(fontSize: 11)),
                  trailing: isActive ? const Icon(Icons.check, color: AppColors.accentBlue) : null,
                  onTap: () { Navigator.pop(context); onSelect(p); },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  IconData _provIcon(AIProviderType t) {
    switch (t) {
      case AIProviderType.openai: return Icons.auto_awesome;
      case AIProviderType.anthropic: return Icons.psychology;
      case AIProviderType.google: return Icons.colorize;
      case AIProviderType.groq: return Icons.bolt;
      case AIProviderType.ollama:
      case AIProviderType.lmstudio:
      case AIProviderType.local: return Icons.computer;
      default: return Icons.cloud;
    }
  }
}
