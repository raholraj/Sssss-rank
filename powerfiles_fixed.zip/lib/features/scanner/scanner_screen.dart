import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';

enum ScanMode { duplicates, junk, large }

class ScannerScreen extends ConsumerStatefulWidget {
  const ScannerScreen({super.key});
  @override
  ConsumerState<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends ConsumerState<ScannerScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isScanning = false;
  List<Map> _dupGroups = [];
  List<Map> _junkFiles = [];
  List<Map> _largeFiles = [];
  Set<String> _selectedForDelete = {};
  double _scanProgress = 0;
  String _scanStatus = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: const Text('Smart Scanner'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.accentBlue,
          labelColor: AppColors.accentBlue,
          unselectedLabelColor: AppColors.textSecondary,
          tabs: const [
            Tab(icon: Icon(Icons.content_copy, size: 18), text: 'Duplicates'),
            Tab(icon: Icon(Icons.delete_sweep, size: 18), text: 'Junk'),
            Tab(icon: Icon(Icons.filter_list, size: 18), text: 'Large Files'),
          ],
        ),
      ),
      body: Column(
        children: [
          if (_isScanning) _buildProgressBar(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildDuplicatesTab(),
                _buildJunkTab(),
                _buildLargeFilesTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _isScanning ? null : _startScan,
        backgroundColor: _isScanning ? AppColors.textDisabled : AppColors.accentBlue,
        icon: _isScanning
            ? const SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : const Icon(Icons.search),
        label: Text(_isScanning ? 'Scanning...' : 'Scan Now'),
      ),
    );
  }

  Widget _buildProgressBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: AppColors.bgSecondary,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_scanStatus, style: const TextStyle(
              fontSize: 12, color: AppColors.textSecondary)),
            Text('${(_scanProgress * 100).toInt()}%',
                style: const TextStyle(fontSize: 12, color: AppColors.accentBlue)),
          ]),
          const SizedBox(height: 6),
          LinearProgressIndicator(
            value: _scanProgress,
            backgroundColor: AppColors.border,
            color: AppColors.accentBlue,
          ),
        ],
      ),
    );
  }

  Widget _buildDuplicatesTab() {
    if (_dupGroups.isEmpty) return _buildEmptyState(
      Icons.content_copy,
      'Find Duplicate Files',
      'Scan to find exact duplicate files and free up space.',
    );

    final totalWasted = _dupGroups.fold<int>(0,
        (sum, g) => sum + (g['wastedBytes'] as num).toInt());

    return Column(
      children: [
        _buildScanSummary(
          '${_dupGroups.length} duplicate groups',
          'Wasted: ${_fmtBytes(totalWasted)}',
          AppColors.accentRed,
          trailingAction: _selectedForDelete.isNotEmpty
              ? ElevatedButton.icon(
                  onPressed: _deleteSelected,
                  icon: const Icon(Icons.delete, size: 16),
                  label: Text('Delete (${_selectedForDelete.length})'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.accentRed, padding: const EdgeInsets.symmetric(horizontal: 12),
                  ),
                )
              : TextButton(
                  onPressed: _selectAllDuplicates,
                  child: const Text('Select All Dups'),
                ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _dupGroups.length,
            itemBuilder: (_, i) => _buildDupGroup(_dupGroups[i], i),
          ),
        ),
      ],
    );
  }

  Widget _buildDupGroup(Map group, int groupIndex) {
    final paths = (group['paths'] as List).cast<String>();
    final size = (group['size'] as num).toInt();
    final wasted = (group['wastedBytes'] as num).toInt();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.accentRed.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text('Group ${groupIndex + 1}',
                    style: const TextStyle(fontSize: 11, color: AppColors.accentRed, fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 8),
              Text('${paths.length} copies  ·  wasted ${_fmtBytes(wasted)}',
                  style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              const Spacer(),
              Text(_fmtBytes(size),
                  style: const TextStyle(fontSize: 12, color: AppColors.textPrimary, fontWeight: FontWeight.w600)),
            ]),
          ),
          ...paths.asMap().entries.map((entry) {
            final i = entry.key;
            final path = entry.value;
            final isOriginal = i == 0;
            final isSelected = _selectedForDelete.contains(path);

            return InkWell(
              onTap: () => setState(() {
                if (!isOriginal) {
                  if (isSelected) _selectedForDelete.remove(path);
                  else _selectedForDelete.add(path);
                }
              }),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.accentRed.withOpacity(0.08) : null,
                  border: Border(top: BorderSide(color: AppColors.border)),
                ),
                child: Row(children: [
                  if (isOriginal)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.accentGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: const Text('KEEP', style: TextStyle(
                        fontSize: 9, color: AppColors.accentGreen, fontWeight: FontWeight.bold,
                      )),
                    )
                  else
                    Checkbox(
                      value: isSelected,
                      onChanged: (_) {
                        setState(() {
                          if (isSelected) _selectedForDelete.remove(path);
                          else _selectedForDelete.add(path);
                        });
                      },
                    ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      path.split('/').last,
                      style: TextStyle(
                        fontSize: 13,
                        color: isSelected ? AppColors.accentRed : AppColors.textPrimary,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    path.replaceAll('/' + path.split('/').last, ''),
                    style: const TextStyle(fontSize: 10, color: AppColors.textDisabled),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ]),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildJunkTab() {
    if (_junkFiles.isEmpty) return _buildEmptyState(
      Icons.delete_sweep,
      'Find Junk Files',
      'Scan for temp files, empty folders, cache files, and other clutter.',
    );

    final totalSize = _junkFiles.fold<int>(0, (sum, f) => sum + (f['size'] as num).toInt());

    return Column(
      children: [
        _buildScanSummary(
          '${_junkFiles.length} junk files found',
          'Total: ${_fmtBytes(totalSize)}',
          AppColors.accentAmber,
          trailingAction: ElevatedButton.icon(
            onPressed: () => _deleteJunkFiles(_junkFiles.map((f) => f['path'] as String).toList()),
            icon: const Icon(Icons.cleaning_services, size: 16),
            label: const Text('Clean All'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accentAmber,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 12),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _junkFiles.length,
            itemBuilder: (_, i) {
              final file = _junkFiles[i];
              return ListTile(
                leading: Icon(
                  file['isDirectory'] == true ? Icons.folder_open : Icons.delete_outline,
                  color: AppColors.accentAmber, size: 20,
                ),
                title: Text(file['name'] as String,
                    style: const TextStyle(fontSize: 13)),
                subtitle: Text('${file['reason']}  ·  ${_fmtBytes((file['size'] as num).toInt())}',
                    style: const TextStyle(fontSize: 11)),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: AppColors.accentRed, size: 18),
                  onPressed: () => _deleteJunkFiles([file['path'] as String]),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildLargeFilesTab() {
    if (_largeFiles.isEmpty) return _buildEmptyState(
      Icons.filter_list,
      'Find Large Files',
      'Scan to find the biggest files taking up your storage.',
    );

    return Column(
      children: [
        _buildScanSummary(
          'Top ${_largeFiles.length} largest files',
          'Tap to open, long-press to delete',
          AppColors.accentPurple,
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _largeFiles.length,
            itemBuilder: (_, i) {
              final file = _largeFiles[i];
              final size = (file['size'] as num).toInt();
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.accentPurple.withOpacity(0.15),
                  child: Text('${i + 1}',
                      style: const TextStyle(fontSize: 11, color: AppColors.accentPurple,
                          fontWeight: FontWeight.bold)),
                ),
                title: Text(file['name'] as String,
                    style: const TextStyle(fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(_shortPath(file['path'] as String),
                    style: const TextStyle(fontSize: 11, color: AppColors.textDisabled),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(_fmtBytes(size), style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                    )),
                    Text(file['extension'] as String? ?? '',
                        style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildScanSummary(String title, String subtitle, Color color,
      {Widget? trailingAction}) {
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(children: [
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600, color: color,
            )),
            const SizedBox(height: 2),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          ],
        )),
        if (trailingAction != null) trailingAction,
      ]),
    );
  }

  Widget _buildEmptyState(IconData icon, String title, String subtitle) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 72, color: AppColors.textDisabled),
            const SizedBox(height: 20),
            Text(title, style: const TextStyle(
              fontSize: 20, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
            )),
            const SizedBox(height: 8),
            Text(subtitle, style: const TextStyle(
              fontSize: 14, color: AppColors.textSecondary, height: 1.5,
            ), textAlign: TextAlign.center),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _startScan,
              icon: const Icon(Icons.search),
              label: const Text('Start Scan'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _startScan() async {
    setState(() { _isScanning = true; _scanProgress = 0; _scanStatus = 'Preparing scan...'; });
    try {
      final root = await fileService.getStorageRoot();

      // Scan duplicates
      setState(() { _scanStatus = 'Finding duplicate candidates...'; _scanProgress = 0.1; });
      final dupCandidates = await fileService.getDuplicateCandidates(root);

      setState(() { _scanStatus = 'Verifying duplicates by hash...'; _scanProgress = 0.4; });
      _dupGroups = dupCandidates.where((g) => (g['paths'] as List).length > 1).toList();

      // Scan junk
      setState(() { _scanStatus = 'Scanning for junk files...'; _scanProgress = 0.6; });
      _junkFiles = await fileService.getJunkFiles(root);

      // Scan large files
      setState(() { _scanStatus = 'Finding large files...'; _scanProgress = 0.85; });
      _largeFiles = await fileService.getLargeFiles(root, minSizeMB: 20);

      setState(() { _isScanning = false; _scanProgress = 1.0; _scanStatus = 'Scan complete!'; });
    } catch (e) {
      setState(() { _isScanning = false; _scanStatus = 'Scan failed: $e'; });
    }
  }

  Future<void> _deleteSelected() async {
    final toDelete = _selectedForDelete.toList();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Duplicates'),
        content: Text('Delete ${toDelete.length} duplicate files? They will be moved to Recycle Bin.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentRed),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    for (final path in toDelete) {
      await fileService.deleteFile(path);
    }
    setState(() { _selectedForDelete.clear(); });
    await _startScan();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${toDelete.length} duplicates deleted')),
    );
  }

  Future<void> _deleteJunkFiles(List<String> paths) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clean Junk'),
        content: Text('Delete ${paths.length} junk files?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentAmber,
                foregroundColor: Colors.black),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clean'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    for (final path in paths) { await fileService.deleteFile(path); }
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${paths.length} junk files deleted')),
    );
    setState(() { _junkFiles.removeWhere((f) => paths.contains(f['path'])); });
  }

  void _selectAllDuplicates() {
    setState(() {
      for (final group in _dupGroups) {
        final paths = (group['paths'] as List).cast<String>();
        _selectedForDelete.addAll(paths.skip(1));
      }
    });
  }

  String _fmtBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  String _shortPath(String path) {
    final parts = path.split('/');
    if (parts.length <= 3) return path;
    return '.../${parts.sublist(parts.length - 3, parts.length - 1).join('/')}';
  }
}
