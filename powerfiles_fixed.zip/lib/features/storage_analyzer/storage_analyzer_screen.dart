import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';

class StorageAnalyzerScreen extends ConsumerStatefulWidget {
  const StorageAnalyzerScreen({super.key});
  @override
  ConsumerState<StorageAnalyzerScreen> createState() => _StorageAnalyzerScreenState();
}

class _StorageAnalyzerScreenState extends ConsumerState<StorageAnalyzerScreen> {
  Map<String, dynamic>? _stats;
  Map<String, int>? _breakdown;
  bool _isLoading = true;
  int _touchedIndex = -1;

  final _categories = [
    _Category('Images', AppColors.colorImage, Icons.image),
    _Category('Videos', AppColors.colorVideo, Icons.videocam),
    _Category('Audio', AppColors.colorAudio, Icons.music_note),
    _Category('Documents', AppColors.colorDocument, Icons.description),
    _Category('APKs', AppColors.colorApk, Icons.android),
    _Category('Archives', AppColors.colorArchive, Icons.archive),
    _Category('Other', AppColors.textSecondary, Icons.more_horiz),
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final stats = await fileService.getStorageStats();
      final breakdown = await fileService.getCategoryBreakdown();
      setState(() {
        _stats = Map<String, dynamic>.from(stats);
        _breakdown = breakdown.map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: const Text('Storage'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadData),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.accentBlue))
          : RefreshIndicator(
              onRefresh: _loadData,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  _buildStorageHeader(),
                  const SizedBox(height: 24),
                  _buildPieChart(),
                  const SizedBox(height: 24),
                  _buildCategoryList(),
                  const SizedBox(height: 16),
                  _buildCleanupSection(),
                ]),
              ),
            ),
    );
  }

  Widget _buildStorageHeader() {
    if (_stats == null) return const SizedBox.shrink();
    final total = (_stats!['totalBytes'] as num).toInt();
    final used = (_stats!['usedBytes'] as num).toInt();
    final free = (_stats!['freeBytes'] as num).toInt();
    final percent = (_stats!['percentUsed'] as num).toInt();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.storage, color: AppColors.accentBlue),
            const SizedBox(width: 8),
            const Text('Internal Storage', style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
            )),
          ]),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(_formatBytes(free), style: const TextStyle(
                fontSize: 40, fontWeight: FontWeight.bold, color: AppColors.textPrimary,
              )),
              const SizedBox(width: 4),
              const Padding(
                padding: EdgeInsets.only(bottom: 6),
                child: Text('Available', style: TextStyle(
                  fontSize: 14, color: AppColors.textSecondary,
                )),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: percent / 100,
              minHeight: 8,
              backgroundColor: AppColors.border,
              color: percent > 90 ? AppColors.accentRed
                  : percent > 75 ? AppColors.accentAmber
                  : AppColors.accentBlue,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${_formatBytes(used)} used  ·  ${_formatBytes(total)} total  ·  $percent% full',
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _buildPieChart() {
    if (_breakdown == null) return const SizedBox.shrink();

    final total = _breakdown!.values.fold(0, (sum, v) => sum + v);
    if (total == 0) return const SizedBox.shrink();

    final sections = _categories.asMap().entries.map((entry) {
      final i = entry.key;
      final cat = entry.value;
      final bytes = _breakdown![cat.key.toLowerCase()] ?? 0;
      final pct = bytes / total * 100;
      final isTouched = i == _touchedIndex;

      return PieChartSectionData(
        value: bytes.toDouble(),
        color: cat.color,
        title: pct > 8 ? '${pct.toStringAsFixed(0)}%' : '',
        radius: isTouched ? 80 : 70,
        titleStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white),
        badgeWidget: isTouched
            ? Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: cat.color, shape: BoxShape.circle),
                child: Icon(cat.icon, color: Colors.white, size: 16),
              )
            : null,
        badgePositionPercentageOffset: 1.1,
      );
    }).toList();

    return Container(
      height: 220,
      child: PieChart(
        PieChartData(
          sections: sections,
          centerSpaceRadius: 60,
          sectionsSpace: 2,
          pieTouchData: PieTouchData(
            touchCallback: (event, response) {
              setState(() {
                if (response?.touchedSection != null) {
                  _touchedIndex = response!.touchedSection!.touchedSectionIndex;
                } else {
                  _touchedIndex = -1;
                }
              });
            },
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryList() {
    if (_breakdown == null) return const SizedBox.shrink();
    final total = _breakdown!.values.fold(0, (sum, v) => sum + v).toDouble();

    return Column(
      children: _categories.map((cat) {
        final bytes = (_breakdown![cat.key.toLowerCase()] ?? 0).toDouble();
        final pct = total > 0 ? bytes / total : 0.0;
        return _categoryRow(cat, bytes.toInt(), pct);
      }).toList(),
    );
  }

  Widget _categoryRow(_Category cat, int bytes, double pct) {
    return InkWell(
      onTap: () => _drillDown(cat),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
        child: Column(
          children: [
            Row(children: [
              Container(
                width: 10, height: 10,
                decoration: BoxDecoration(color: cat.color, shape: BoxShape.circle),
              ),
              const SizedBox(width: 10),
              Icon(cat.icon, size: 16, color: cat.color),
              const SizedBox(width: 8),
              Expanded(
                child: Text(cat.key, style: const TextStyle(
                  fontSize: 14, color: AppColors.textPrimary,
                )),
              ),
              Text(_formatBytes(bytes), style: const TextStyle(
                fontSize: 14, color: AppColors.textPrimary, fontWeight: FontWeight.w500,
              )),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right, size: 16, color: AppColors.textDisabled),
            ]),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.only(left: 28),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(2),
                child: LinearProgressIndicator(
                  value: pct,
                  minHeight: 4,
                  backgroundColor: AppColors.border,
                  color: cat.color,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCleanupSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Recommended Cleanup',
            style: TextStyle(fontSize: 12, color: AppColors.textSecondary, letterSpacing: 0.5)),
        const SizedBox(height: 8),
        _cleanupTile(Icons.description_outlined, 'Large files',
            '3.49 GB', Colors.orange, () {}),
        _cleanupTile(Icons.history, 'Old files',
            '382 MB', AppColors.accentAmber, () {}),
        _cleanupTile(Icons.folder_outlined, 'Junk files',
            'Tap to scan', AppColors.textSecondary, () {}),
      ],
    );
  }

  Widget _cleanupTile(IconData icon, String label, String size, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: AppColors.border)),
        ),
        child: Row(children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 12),
          Expanded(child: Text(label,
              style: const TextStyle(fontSize: 14, color: AppColors.textPrimary))),
          Text(size, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right, size: 16, color: AppColors.textDisabled),
        ]),
      ),
    );
  }

  void _drillDown(_Category cat) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Loading ${cat.key} breakdown...')),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }
}

class _Category {
  final String key;
  final Color color;
  final IconData icon;
  const _Category(this.key, this.color, this.icon);
}
