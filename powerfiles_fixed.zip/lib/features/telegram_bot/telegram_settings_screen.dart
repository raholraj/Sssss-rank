import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';

// ── Telegram Service ──
class TelegramService {
  static const _baseUrl = 'https://api.telegram.org/bot';
  static const _prefsToken = 'tg_token';
  static const _prefsChatId = 'tg_chat_id';

  String? _token;
  String? _chatId;
  bool _isRunning = false;
  Timer? _pollTimer;
  int _lastUpdateId = 0;

  Stream<String> get logs => _logController.stream;
  final _logController = StreamController<String>.broadcast();

  bool get isConnected => _token != null && _chatId != null;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_prefsToken);
    _chatId = prefs.getString(_prefsChatId);
    if (isConnected) _startPolling();
  }

  Future<Map<String, dynamic>> connect(String token, String chatId) async {
    try {
      final res = await http.get(Uri.parse('$_baseUrl$token/getMe')).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['ok'] != true) return {'success': false, 'error': data['description']};
      final botName = data['result']['username'];
      _token = token;
      _chatId = chatId;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsToken, token);
      await prefs.setString(_prefsChatId, chatId);
      _startPolling();
      return {'success': true, 'botName': botName};
    } catch (e) {
      return {'success': false, 'error': e.toString()};
    }
  }

  void disconnect() {
    _pollTimer?.cancel();
    _isRunning = false;
    _token = null;
    _chatId = null;
    SharedPreferences.getInstance().then((p) {
      p.remove(_prefsToken);
      p.remove(_prefsChatId);
    });
  }

  void _startPolling() {
    _isRunning = true;
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
  }

  Future<void> _poll() async {
    if (_token == null || !_isRunning) return;
    try {
      final res = await http.get(
        Uri.parse('$_baseUrl$_token/getUpdates?offset=${_lastUpdateId + 1}&timeout=0'),
      ).timeout(const Duration(seconds: 5));
      final data = jsonDecode(res.body);
      if (data['ok'] != true) return;
      for (final update in data['result']) {
        _lastUpdateId = update['update_id'];
        final msg = update['message'];
        if (msg == null) continue;
        final fromId = msg['chat']['id'].toString();
        if (fromId != _chatId) continue; // Security: ignore other users
        final text = msg['text'] as String? ?? '';
        _log('Received: $text');
        await _handleCommand(text);
      }
    } catch (_) {}
  }

  Future<void> _handleCommand(String text) async {
    final parts = text.split(' ');
    final cmd = parts[0].toLowerCase();
    final args = parts.skip(1).join(' ');

    switch (cmd) {
      case '/start':
      case '/help':
        await sendMessage(_helpText);
        break;
      case '/storage':
        final stats = await fileService.getStorageStats();
        final used = stats['usedBytes'] as int;
        final free = stats['freeBytes'] as int;
        final pct = stats['percentUsed'] as int;
        await sendMessage('💾 Storage\nUsed: ${_fmt(used)}\nFree: ${_fmt(free)}\n$pct% full');
        break;
      case '/ls':
        final path = args.isNotEmpty ? args : '/storage/emulated/0';
        try {
          final files = await fileService.listDirectory(path);
          final list = files.take(20).map((f) =>
            '${f.isDirectory ? "📁" : "📄"} ${f.name}${f.isDirectory ? "/" : " (${f.formattedSize})"}').join('\n');
          await sendMessage('📂 $path\n\n$list${files.length > 20 ? "\n...and ${files.length - 20} more" : ""}');
        } catch (e) {
          await sendMessage('Error: $e');
        }
        break;
      case '/find':
        if (args.isEmpty) { await sendMessage('Usage: /find <filename>'); break; }
        final root = await fileService.getStorageRoot();
        final results = await fileService.searchFiles(args, root);
        if (results.isEmpty) {
          await sendMessage('No files found for "$args"');
        } else {
          final list = results.take(10).map((f) => '📄 ${f.path}').join('\n');
          await sendMessage('🔍 Found ${results.length} files:\n$list');
        }
        break;
      case '/big':
        final n = int.tryParse(args) ?? 10;
        final root = await fileService.getStorageRoot();
        final large = await fileService.getLargeFiles(root, minSizeMB: 10);
        final list = large.take(n).asMap().entries.map((e) =>
          '${e.key + 1}. ${e.value['name']} (${_fmt((e.value['size'] as num).toInt())})').join('\n');
        await sendMessage('📊 Top $n largest files:\n$list');
        break;
      case '/free':
        final stats = await fileService.getStorageStats();
        final free = stats['freeBytes'] as int;
        await sendMessage('💚 Free space: ${_fmt(free)}');
        break;
      case '/status':
        await sendMessage('✅ PowerFiles is running\nStorage: ${(await fileService.getStorageStats())['percentUsed']}% used');
        break;
      case '/screenshot':
        await sendMessage('📸 Screenshot feature requires display access. Coming soon!');
        break;
      default:
        if (cmd.startsWith('/')) await sendMessage('Unknown command: $cmd\nSend /help for command list');
    }
  }

  Future<bool> sendMessage(String text) async {
    if (_token == null || _chatId == null) return false;
    try {
      await http.post(
        Uri.parse('$_baseUrl$_token/sendMessage'),
        body: {'chat_id': _chatId!, 'text': text, 'parse_mode': 'HTML'},
      );
      _log('Sent: ${text.substring(0, text.length.clamp(0, 50))}...');
      return true;
    } catch (e) {
      _log('Send error: $e');
      return false;
    }
  }

  Future<bool> sendFile(String path) async {
    if (_token == null || _chatId == null) return false;
    try {
      final req = http.MultipartRequest('POST',
          Uri.parse('$_baseUrl$_token/sendDocument'));
      req.fields['chat_id'] = _chatId!;
      req.files.add(await http.MultipartFile.fromPath('document', path));
      final res = await req.send();
      return res.statusCode == 200;
    } catch (_) { return false; }
  }

  void _log(String msg) => _logController.add('[${DateTime.now().toLocal().toString().substring(11, 19)}] $msg');

  String _fmt(int bytes) {
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  static const _helpText = '''🤖 <b>PowerFiles Bot Commands</b>

📁 <b>File Operations</b>
/ls [path] - List folder contents
/find &lt;name&gt; - Search for file
/info &lt;path&gt; - File details

📊 <b>Storage</b>
/storage - Full storage breakdown
/big [n] - Top N largest files
/free - Available space

⚙️ <b>System</b>
/status - App status
/screenshot - Take screenshot
/help - This message''';
}

final telegramService = TelegramService();

// ── Telegram Settings Screen ──
class TelegramSettingsScreen extends StatefulWidget {
  const TelegramSettingsScreen({super.key});
  @override
  State<TelegramSettingsScreen> createState() => _TelegramSettingsScreenState();
}

class _TelegramSettingsScreenState extends State<TelegramSettingsScreen> {
  final _tokenCtrl = TextEditingController();
  final _chatIdCtrl = TextEditingController();
  bool _isConnecting = false;
  bool _isConnected = false;
  String? _botName;
  final _logs = <String>[];
  StreamSubscription? _logSub;

  @override
  void initState() {
    super.initState();
    telegramService.init().then((_) {
      if (mounted) setState(() => _isConnected = telegramService.isConnected);
    });
    _logSub = telegramService.logs.listen((msg) {
      if (mounted) setState(() {
        _logs.insert(0, msg);
        if (_logs.length > 100) _logs.removeLast();
      });
    });
  }

  @override
  void dispose() {
    _tokenCtrl.dispose();
    _chatIdCtrl.dispose();
    _logSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(title: const Text('Telegram Bot')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _buildStatusCard(),
          const SizedBox(height: 20),
          if (!_isConnected) _buildSetupForm(),
          if (_isConnected) _buildControls(),
          const SizedBox(height: 20),
          _buildCommandReference(),
          const SizedBox(height: 20),
          if (_logs.isNotEmpty) _buildLogView(),
        ]),
      ),
    );
  }

  Widget _buildStatusCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _isConnected
            ? AppColors.accentGreen.withOpacity(0.08)
            : AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isConnected ? AppColors.accentGreen.withOpacity(0.3) : AppColors.border,
        ),
      ),
      child: Row(children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: _isConnected
                ? AppColors.accentGreen.withOpacity(0.15)
                : AppColors.textDisabled.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            Icons.telegram,
            color: _isConnected ? AppColors.accentGreen : AppColors.textDisabled,
            size: 24,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _isConnected ? 'Connected' : 'Not Connected',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 15,
                color: _isConnected ? AppColors.accentGreen : AppColors.textSecondary,
              ),
            ),
            if (_botName != null)
              Text('@$_botName', style: const TextStyle(
                fontSize: 12, color: AppColors.textSecondary,
              )),
          ],
        )),
        if (_isConnected)
          TextButton(
            onPressed: _disconnect,
            child: const Text('Disconnect', style: TextStyle(color: AppColors.accentRed)),
          ),
      ]),
    );
  }

  Widget _buildSetupForm() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Setup', style: TextStyle(
        fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
      )),
      const SizedBox(height: 4),
      const Text(
        'Create a bot via @BotFather on Telegram, then enter the token and your Chat ID below.',
        style: TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.5),
      ),
      const SizedBox(height: 16),
      TextField(
        controller: _tokenCtrl,
        decoration: const InputDecoration(
          labelText: 'Bot Token',
          hintText: '1234567890:AAAA-xxxx...',
          prefixIcon: Icon(Icons.vpn_key_outlined),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _chatIdCtrl,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: 'Your Chat ID',
          hintText: '123456789',
          helperText: 'Send /getid to @userinfobot on Telegram',
          prefixIcon: const Icon(Icons.person_outline),
        ),
      ),
      const SizedBox(height: 20),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _isConnecting ? null : _connect,
          icon: _isConnecting
              ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : const Icon(Icons.link),
          label: Text(_isConnecting ? 'Connecting...' : 'Connect Bot'),
        ),
      ),
    ]);
  }

  Widget _buildControls() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Quick Actions', style: TextStyle(
        fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
      )),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => telegramService.sendMessage('✅ PowerFiles is alive!'),
            icon: const Icon(Icons.send, size: 16),
            label: const Text('Test Message'),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () async {
              final stats = await fileService.getStorageStats();
              final pct = stats['percentUsed'];
              telegramService.sendMessage('💾 Storage: $pct% used');
            },
            icon: const Icon(Icons.storage, size: 16),
            label: const Text('Send Storage'),
          ),
        ),
      ]),
    ]);
  }

  Widget _buildCommandReference() {
    const commands = [
      ['/ls [path]', 'List folder contents'],
      ['/find <name>', 'Search for file'],
      ['/storage', 'Storage breakdown'],
      ['/big [n]', 'Top N largest files'],
      ['/free', 'Available space'],
      ['/status', 'App status'],
      ['/help', 'Command list'],
    ];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Commands', style: TextStyle(
        fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
      )),
      const SizedBox(height: 10),
      Container(
        decoration: BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: commands.asMap().entries.map((e) {
            final cmd = e.value;
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                border: e.key < commands.length - 1
                    ? const Border(bottom: BorderSide(color: AppColors.border))
                    : null,
              ),
              child: Row(children: [
                Text(cmd[0], style: const TextStyle(
                  fontFamily: 'monospace', fontSize: 12,
                  color: AppColors.accentCyan, fontWeight: FontWeight.w600,
                )),
                const SizedBox(width: 12),
                Expanded(child: Text(cmd[1], style: const TextStyle(
                  fontSize: 12, color: AppColors.textSecondary,
                ))),
              ]),
            );
          }).toList(),
        ),
      ),
    ]);
  }

  Widget _buildLogView() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Activity Log', style: TextStyle(
          fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
        )),
        TextButton(
          onPressed: () => setState(() => _logs.clear()),
          child: const Text('Clear', style: TextStyle(fontSize: 12)),
        ),
      ]),
      const SizedBox(height: 8),
      Container(
        height: 200,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppColors.border),
        ),
        child: ListView.builder(
          reverse: false,
          itemCount: _logs.length,
          itemBuilder: (_, i) => Text(
            _logs[i],
            style: const TextStyle(
              fontFamily: 'monospace', fontSize: 11, color: AppColors.textSecondary,
            ),
          ),
        ),
      ),
    ]);
  }

  Future<void> _connect() async {
    if (_tokenCtrl.text.isEmpty || _chatIdCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in both fields')),
      );
      return;
    }
    setState(() => _isConnecting = true);
    final result = await telegramService.connect(_tokenCtrl.text.trim(), _chatIdCtrl.text.trim());
    setState(() {
      _isConnecting = false;
      if (result['success'] == true) {
        _isConnected = true;
        _botName = result['botName'];
      }
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result['success'] == true
            ? '✅ Connected to @${result['botName']}'
            : '❌ ${result['error']}'),
      ));
    }
  }

  void _disconnect() {
    telegramService.disconnect();
    setState(() { _isConnected = false; _botName = null; _logs.clear(); });
  }
}
