import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../app/theme.dart';
import '../../core/services/file_service.dart';

class Project {
  final String id;
  final String name;
  final String description;
  final List<String> paths;
  final DateTime createdAt;
  DateTime lastModified;
  final String? gitUrl;
  final Color color;

  Project({
    required this.id, required this.name, this.description = '',
    required this.paths, required this.createdAt, required this.lastModified,
    this.gitUrl, required this.color,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'description': description, 'paths': paths,
    'createdAt': createdAt.toIso8601String(),
    'lastModified': lastModified.toIso8601String(),
    'gitUrl': gitUrl, 'colorValue': color.value,
  };

  factory Project.fromJson(Map<String, dynamic> j) => Project(
    id: j['id'], name: j['name'], description: j['description'] ?? '',
    paths: List<String>.from(j['paths']),
    createdAt: DateTime.parse(j['createdAt']),
    lastModified: DateTime.parse(j['lastModified']),
    gitUrl: j['gitUrl'],
    color: Color(j['colorValue'] ?? AppColors.accentBlue.value),
  );
}

class ProjectsScreen extends StatefulWidget {
  const ProjectsScreen({super.key});
  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen> {
  List<Project> _projects = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('projects') ?? [];
    setState(() => _projects = raw.map((s) => Project.fromJson(jsonDecode(s))).toList());
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('projects', _projects.map((p) => jsonEncode(p.toJson())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        title: const Text('Projects'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showCreateDialog(context),
          ),
        ],
      ),
      body: _projects.isEmpty ? _buildEmpty() : _buildList(),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.folder_special_outlined, size: 72, color: AppColors.textDisabled),
        const SizedBox(height: 20),
        const Text('No Projects Yet', style: TextStyle(
          fontSize: 20, fontWeight: FontWeight.w600, color: AppColors.textPrimary,
        )),
        const SizedBox(height: 8),
        const Text(
          'Create a project to group related files\nand folders into a virtual workspace.',
          style: TextStyle(fontSize: 14, color: AppColors.textSecondary, height: 1.5),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 28),
        ElevatedButton.icon(
          onPressed: () => _showCreateDialog(context),
          icon: const Icon(Icons.add), label: const Text('New Project'),
        ),
      ]),
    );
  }

  Widget _buildList() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _projects.length,
      itemBuilder: (_, i) => _ProjectCard(
        project: _projects[i],
        onOpen: () => _openProject(context, _projects[i]),
        onEdit: () => _showEditDialog(context, _projects[i]),
        onDelete: () => _deleteProject(_projects[i].id),
      ),
    );
  }

  void _showCreateDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final pathCtrl = TextEditingController(text: '/storage/emulated/0/');
    Color selectedColor = AppColors.accentBlue;

    final colors = [
      AppColors.accentBlue, AppColors.accentCyan, AppColors.accentGreen,
      AppColors.accentAmber, AppColors.accentRed, AppColors.accentPurple,
    ];

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setDlgState) => AlertDialog(
          title: const Text('New Project'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(
                labelText: 'Project Name *', hintText: 'My Flutter App',
              )),
              const SizedBox(height: 12),
              TextField(controller: descCtrl, decoration: const InputDecoration(
                labelText: 'Description', hintText: 'What is this project?',
              )),
              const SizedBox(height: 12),
              TextField(controller: pathCtrl, decoration: const InputDecoration(
                labelText: 'Root Path', hintText: '/storage/emulated/0/MyProject',
                prefixIcon: Icon(Icons.folder_outlined),
              )),
              const SizedBox(height: 14),
              Row(children: [
                const Text('Color: ', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                ...colors.map((c) => GestureDetector(
                  onTap: () => setDlgState(() => selectedColor = c),
                  child: Container(
                    margin: const EdgeInsets.only(left: 6),
                    width: 24, height: 24,
                    decoration: BoxDecoration(
                      color: c, shape: BoxShape.circle,
                      border: selectedColor == c
                          ? Border.all(color: Colors.white, width: 2) : null,
                    ),
                  ),
                )),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                if (nameCtrl.text.isEmpty) return;
                final p = Project(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  name: nameCtrl.text,
                  description: descCtrl.text,
                  paths: [pathCtrl.text.trim()],
                  createdAt: DateTime.now(),
                  lastModified: DateTime.now(),
                  color: selectedColor,
                );
                setState(() => _projects.insert(0, p));
                _save();
                Navigator.pop(context);
              },
              child: const Text('Create'),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditDialog(BuildContext context, Project p) {
    final nameCtrl = TextEditingController(text: p.name);
    final descCtrl = TextEditingController(text: p.description);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Project'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 12),
          TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Description')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final idx = _projects.indexWhere((x) => x.id == p.id);
              if (idx >= 0) {
                _projects[idx] = Project(
                  id: p.id, name: nameCtrl.text, description: descCtrl.text,
                  paths: p.paths, createdAt: p.createdAt,
                  lastModified: DateTime.now(), gitUrl: p.gitUrl, color: p.color,
                );
                setState(() {});
                _save();
              }
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _openProject(BuildContext context, Project p) {
    if (p.paths.isNotEmpty) {
      // Navigate to file browser at project root
      context.go('/files');
    }
  }

  void _deleteProject(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Project'),
        content: const Text('Remove this project? Files on disk will NOT be deleted.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.accentRed),
            onPressed: () {
              setState(() => _projects.removeWhere((p) => p.id == id));
              _save();
              Navigator.pop(context);
            },
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }
}

class _ProjectCard extends StatelessWidget {
  final Project project;
  final VoidCallback onOpen;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _ProjectCard({
    required this.project, required this.onOpen,
    required this.onEdit, required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onOpen,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [project.color.withOpacity(0.08), Colors.transparent],
          ),
        ),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: project.color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: project.color.withOpacity(0.3)),
            ),
            child: Icon(Icons.folder_special, color: project.color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(project.name, style: const TextStyle(
              fontWeight: FontWeight.w600, fontSize: 15, color: AppColors.textPrimary,
            )),
            if (project.description.isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(project.description, style: const TextStyle(
                fontSize: 12, color: AppColors.textSecondary,
              ), maxLines: 1, overflow: TextOverflow.ellipsis),
            ],
            const SizedBox(height: 4),
            Row(children: [
              Icon(Icons.folder_outlined, size: 12, color: AppColors.textDisabled),
              const SizedBox(width: 4),
              Text(project.paths.first, style: const TextStyle(
                fontSize: 11, color: AppColors.textDisabled, fontFamily: 'monospace',
              ), maxLines: 1, overflow: TextOverflow.ellipsis),
            ]),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            PopupMenuButton(
              icon: const Icon(Icons.more_vert, size: 18, color: AppColors.textSecondary),
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'open', child: Text('Open in Files')),
                const PopupMenuItem(value: 'editor', child: Text('Open in Editor')),
                const PopupMenuItem(value: 'terminal', child: Text('Open Terminal')),
                const PopupMenuItem(value: 'ai', child: Text('Ask AI about project')),
                const PopupMenuItem(value: 'edit', child: Text('Edit Project')),
                const PopupMenuItem(value: 'delete', child: Text('Remove Project',
                    style: TextStyle(color: AppColors.accentRed))),
              ],
              onSelected: (v) {
                if (v == 'edit') onEdit();
                if (v == 'delete') onDelete();
                if (v == 'open') onOpen();
                if (v == 'editor') context.push('/editor');
                if (v == 'terminal') context.push('/terminal');
                if (v == 'ai') context.push('/ai');
              },
            ),
            Text(
              _relativeDate(project.lastModified),
              style: const TextStyle(fontSize: 10, color: AppColors.textDisabled),
            ),
          ]),
        ]),
      ),
    );
  }

  String _relativeDate(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inDays == 0) return 'Today';
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
